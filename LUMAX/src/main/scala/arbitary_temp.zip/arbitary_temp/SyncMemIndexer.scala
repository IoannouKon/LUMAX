package Data_Reuse
import chisel3._
import chisel3.util._

class SyncMemIndexer(
  val width: Int,
  val x_slice_log2: Int,
  val max_val: Int,
  val x_slice: Int,
) extends Module {
  val io = IO(new Bundle {
    val i                 = Input(UInt(width.W))
    val stepCycle_1       = Input(UInt(width.W))
    val step_1            = Input(UInt(width.W))
    val counter_1         = Input(UInt(width.W))
    val cycleCount_1      = Input(UInt(width.W))
    val block_rows_1      = Input(UInt(3.W))
    val blocks_in_Sync_mem_1 = Input(UInt(2.W))
    val weight_bits       = Input(UInt(4.W))

    val sync_mem_idx      = Output(UInt(width.W))
    val finalAddressInBRAM= Output(UInt(width.W))
    val x_th_x_reg        = Output(UInt(width.W))
    val y_th_xreg         = Output(UInt(width.W))
  })

  val x_slice_mask = (x_slice - 1).U
  val max_mask = (max_val - 1).U

  val sync_mem_idx = io.stepCycle_1 * io.step_1 + io.i
  io.sync_mem_idx := sync_mem_idx

  val shiftAmt = Mux(io.block_rows_1 === 4.U, 2.U, 6.U)
  val start_row = io.counter_1 << shiftAmt
  io.finalAddressInBRAM := start_row + (io.cycleCount_1 - 1.U)

  io.x_th_x_reg := Mux(
    io.blocks_in_Sync_mem_1 === 1.U,
    (sync_mem_idx & x_slice_mask) + io.counter_1,
    ((sync_mem_idx << 4) + io.counter_1) & max_mask
  )

  io.y_th_xreg := Mux(
    io.weight_bits === 8.U,
    sync_mem_idx >> x_slice_log2.U,
    ((sync_mem_idx << 4) + io.counter_1) >> log2Ceil(max_val)
  )
}
