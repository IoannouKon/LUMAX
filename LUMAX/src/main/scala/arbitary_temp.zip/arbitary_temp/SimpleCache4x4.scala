package Data_Reuse
import chisel3._
import chisel3.util._

import chisel3._
import chisel3.util._


//Important XBitWidth == WBitWidth

class SimpleCache4x4(XBitWidth: Int, WBitWidth: Int) extends Module {
  require(XBitWidth == WBitWidth, "XBitWidth and WBitWidth must be equal")
  require(XBitWidth % 4 == 0, "Widths must be multiple of 4")

  val NumChunks = XBitWidth / 4

  val io = IO(new Bundle {
    val x   = Input(SInt(XBitWidth.W))
    val w   = Input(SInt(WBitWidth.W))
    val out = Output(Vec(NumChunks, SInt(8.W)))
  })

  val elem4_per_reg = XBitWidth/4 
  // LUT of products for abs(x), abs(w)  81 total elements
  val mulLUT = VecInit(
    (0 to 8).map { x =>
      VecInit((0 to 8).map { w =>
        (x * w).U(8.W)
      })
    }
  )

  val x_u = io.x.asUInt
  val w_u = io.w.asUInt

  //split register to 4 bits 
  for (i <- 0 until NumChunks) {
    val lo = i << 2
    val hi = lo + 3

    val x_chunk = x_u(hi, lo)
    val w_chunk = w_u(hi, lo)

    val x_sint = x_chunk.asSInt
    val w_sint = w_chunk.asSInt

    val x_sign = x_chunk(3)
    val w_sign = w_chunk(3)

    val absX = Mux(x_sign, (-x_sint).asUInt, x_chunk)
    val absW = Mux(w_sign, (-w_sint).asUInt, w_chunk)

    val unsignedProduct = mulLUT(absX)(absW)

    val outputSign = x_sign ^ w_sign
    val signedProduct = Mux(outputSign, -unsignedProduct.asSInt, unsignedProduct.asSInt)

    io.out(i) := signedProduct
  }
}



