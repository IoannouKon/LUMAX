package Data_Reuse
import chisel3._
import chisel3.util._

class product_calculation(
  val product_bitwidth: Int,
  val XBitWidth :Int,
  val WBitWidth: Int,
  val maxParts: Int,
) extends Module {
  val io = IO(new Bundle {
    val signedChunk = Input(SInt(XBitWidth.W))
    val P_data = Input(UInt(product_bitwidth.W))
    val k = Input(UInt(log2Ceil(maxParts + 1).W)) // or appropriate width
    val chunks_per_Product_bits = Input(UInt(log2Ceil((((WBitWidth + XBitWidth) ))  + 1).W))
    val mask_p =  Input(UInt((log2Ceil(((1 << (WBitWidth +  XBitWidth) ) - 1 )  + 1)).W))
    val x_elems_per_reg   = Input(UInt(2.W))

    val out = Output(UInt(product_bitwidth.W))
  })

  val absVal = io.signedChunk.abs().asUInt
  val chunk_p = (io.P_data >> (io.k * io.chunks_per_Product_bits)) & io.mask_p
  val scaled = absVal << 1.U
  io.out := Mux(io.k < io.x_elems_per_reg, chunk_p + scaled, chunk_p)
}

