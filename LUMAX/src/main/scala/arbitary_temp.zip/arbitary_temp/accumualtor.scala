package Data_Reuse
import chisel3._
import chisel3.util._

class AccumulatorUnit(product_bitwidth: Int ,y_slice: Int,XBitWidth :Int ,WBitWidth :Int) extends Module {
  val io = IO(new Bundle {
    val w_reg_valid = Input(Bool())
    val product = Input(UInt(product_bitwidth.W))
    val offset = Input(UInt(6.W)) // adjust width as needed
    val sign = Input(Bool())
    val sum = Input(SInt(product_bitwidth.W))
    val data_y = Input(UInt(log2Ceil(y_slice).W)) // or log2Ceil(y_slice).W
    val target_y = Input(UInt(log2Ceil(y_slice).W))
    val chunks_per_Product_bits = Input(UInt(log2Ceil((((WBitWidth +  XBitWidth) ))  + 1).W))   
    val mask_p = Input(UInt(log2Ceil((1 << (WBitWidth + XBitWidth))).W))

    val result = Output(SInt(product_bitwidth.W))
  })

  val valid_read = Mux(io.w_reg_valid, io.product, 0.U)

  val shifted = (valid_read >> (io.offset * io.chunks_per_Product_bits)) & io.mask_p

  val unsigned_clean = Mux1H(Seq(
    (io.chunks_per_Product_bits === 8.U)  -> shifted(7, 0),
    (io.chunks_per_Product_bits === 12.U) -> shifted(11, 0),
    (io.chunks_per_Product_bits === 16.U) -> shifted(15, 0)
  ))

  val signed_clean = unsigned_clean.zext.asSInt
  val signedValue = Mux(io.sign, signed_clean - io.sum, -signed_clean - io.sum)

  io.result := Mux(io.data_y === io.target_y, signedValue, 0.S)
}
