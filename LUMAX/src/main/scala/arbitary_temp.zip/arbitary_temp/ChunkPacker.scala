package Data_Reuse
import chisel3._
import chisel3.util._

class ProductPacker(
  val maxParts: Int,
  val product_bitwidth: Int,
  val WBitWidth: Int,
  val XBitWidth: Int

) extends Module {
  val io = IO(new Bundle {
    val slices = Input(Vec(maxParts, UInt(product_bitwidth.W)))
    val chunks_per_Product_bits = Input(UInt(log2Ceil((((WBitWidth + XBitWidth) ))  + 1).W))
    val packed = Output(UInt(((product_bitwidth.W))))
  })

 val packed = io.slices.zipWithIndex.map { case (slice, i) =>
    slice << (i.U * io.chunks_per_Product_bits)
  }.reduce(_ | _)

  io.packed := packed
}
