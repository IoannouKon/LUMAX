package Data_Reuse
import chisel3._
import chisel3.util._

class WeightBramIndexer(XBitWidth: Int, val RowsPerBlock : Int, val max_w_elems : Int, val buffers : Int ,val WBitWidth : Int, val max_x_regs :Int, val Cout :Int) extends Module {
  val io = IO(new Bundle {
    val weight_Sint_part = Input(SInt(XBitWidth.W))
    val block_rows_2     = Input(UInt(RowsPerBlock.W))                
    val counter_2        = Input(UInt(log2Ceil(RowsPerBlock + 2).W))
    val cycleCount_2     = Input(UInt(log2Ceil(4 + 1).W))
    val w_idx            = Input(UInt(log2Ceil(max_w_elems + 1).W))
    val buff_elems       = Input(UInt((log2Ceil(math.max(max_x_regs,Cout) + 1).W)))

    val row_idx          = Output(UInt(WBitWidth.W))
    // val abs_weight_uint  = Output(UInt(WBitWidth.W))
    val w_reg_valid_temp = Output(Bool())
    val need_x_val       = Output(Bool())

  })

  val abs_weight_uint = io.weight_Sint_part.abs().asUInt

  val shiftAmt = Mux(io.block_rows_2 === 4.U, 2.U, 6.U)
  val start_row = io.counter_2 << shiftAmt

  val row_in_block = Mux(abs_weight_uint(0) === 0.U,(abs_weight_uint >> 1) - 1.U,(abs_weight_uint - 1.U) >> 1)

  val row_idx = start_row + row_in_block
  val elemOffset = io.cycleCount_2

  val w_reg_valid_temp = io.w_idx < io.buff_elems && abs_weight_uint =/= 0.U 

  val disable     = (abs_weight_uint(0) === 0.U) || !w_reg_valid_temp || (abs_weight_uint === 0.U)


  io.row_idx := row_idx
  io.w_reg_valid_temp := w_reg_valid_temp
  // io.abs_weight_uint  := abs_weight_uint
  io.need_x_val := disable
}
