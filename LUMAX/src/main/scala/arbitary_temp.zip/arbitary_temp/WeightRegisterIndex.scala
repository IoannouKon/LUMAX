package Data_Reuse
import chisel3._
import chisel3.util._

class WeightRegisterIndex(
  val step_2: Int,     
  val RowsPerBlock : Int,
  val x_slice : Int, 
  val y_slice : Int,
  val max_w_elems :Int,

) extends Module {
  val io = IO(new Bundle {
    val sync_mem_idx       = Input(UInt((log2Ceil(step_2) + 1).W))
    val counter_2          = Input(UInt(log2Ceil(RowsPerBlock + 2).W))
    val cycleCount_2       = Input(UInt(log2Ceil(4 + 1).W))
    val weight_bits        = Input(UInt(6.W)) 
    val x_elems_per_reg    = Input(UInt(2.W))
    val w_elems_per_reg    = Input(UInt(2.W))
    val dirty_elems_w      = Input(UInt(2.W))


    val W_reg_Index = Output(UInt(log2Ceil(max_w_elems + 1).W))
    val w_offset    = Output(UInt(2.W))
    val x_th_x_reg  = Output(UInt(log2Ceil(x_slice + 1).W))
    val y_th_xreg   = Output(UInt(log2Ceil(y_slice + 1).W))
     val w_idx      = Output(UInt(log2Ceil(max_w_elems + 1).W))

  })

  val x_slice_mask = (x_slice - 1).U
  val x_slice_log2 = log2Ceil(x_slice)
  val max_val = 16 * x_slice
  val max_mask = (max_val - 1).U

  
  val x_th_x_reg = Mux(io.weight_bits === 8.U,
    (io.sync_mem_idx & x_slice_mask) + io.counter_2,
    ((io.sync_mem_idx << 4) + io.counter_2) & max_mask
  )

  val y_th_xreg = Mux(io.weight_bits === 8.U,
    io.sync_mem_idx >> x_slice_log2,
    ((io.sync_mem_idx << 4) + io.counter_2) >> log2Ceil(max_val)
  )

  val base = x_th_x_reg
  val w_idx = Mux(io.x_elems_per_reg === 1.U,base + io.cycleCount_2,(base << 1) + io.cycleCount_2)

  val w_id_in_reg = w_idx + io.dirty_elems_w
  val linear_w = w_id_in_reg

  io.W_reg_Index := Mux(io.w_elems_per_reg === 1.U, linear_w, linear_w >> 1)
  io.w_offset    := Mux(io.w_elems_per_reg === 1.U, 0.U, linear_w(0))
  io.x_th_x_reg  := x_th_x_reg
  io.y_th_xreg   := y_th_xreg
  io.w_idx       := w_idx
}
