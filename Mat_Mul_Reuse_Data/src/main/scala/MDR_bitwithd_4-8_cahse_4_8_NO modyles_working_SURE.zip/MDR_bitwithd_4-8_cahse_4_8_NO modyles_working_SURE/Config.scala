package Data_Reuse

case class DataReuseParams(
  Rin:            Int,
  Cin:            Int,
  Cout:           Int,
  XBitWidth:      Int, 
  WBitWidth:      Int, 
  OutBitWidth:    Int,
  minInputBits:   Int,
  minWeightBits:  Int, 
  x_slice:        Int,
  y_slice:        Int,
  w_slice:        Int,
  num_filters:    Int,
  Dma_Ids:        Int,
  DMA_Bytes:      Int,
  SCALE:          Boolean,
  DEBUG:          Boolean,
  W_BUFFS:        Int,
  step_1 :        Int,
  step_2 :        Int,
  SimpleCache4x4:  Boolean,
  SimpleCache4x8:  Boolean,
  DMA_bits:       Int,

)

// Create an object to hold your configuration
object Data_Reuse_Config {
  val Data_Reuse_Config = DataReuseParams(

    //Μax Matrix Dimesnions 
    Rin         = 1,  //Used Only for a Counter 
    Cin         = 256, // Used only for OuputBitwidth 
    Cout        = 256, // Used only to a a counter Registers  and how many output stationary outputs we have 
  
    // Element Bidwidths  
    XBitWidth   = 8,  // max Number of bits on input elemetns 
    WBitWidth   = 8,   // max  Number of bits on weights elemetns 
    OutBitWidth = 32,  // max  Number of bits on output elements  
    //params.XBitWidth + params.WBitWidth + Math.ceil(math.log(params.Cin) / math.log(2)).toInt

    //new
    minInputBits  = 4,  //2 4
    minWeightBits = 4,  // 4 
    
    //Max Parallelism Paramters 
    y_slice     =  1,    // IMPORTANT Design parameter  MAX value
    x_slice     =  4,   // IMPORTANT Design parameter  MAX value 
    
    //NOT USED (TODO)
    w_slice     = 1,
    num_filters = 1,

    //DMA 
    Dma_Ids     = 2,  // How many DMA Requests in flight 
    DMA_Bytes   = 8,  // How many bytes send in one request 
    DMA_bits    = 8*8,

    //scale 
    SCALE   = false, //1 or 0  (elaboration-time)

    //Debug from performance counters 
    DEBUG =  true, // 1 or  0

    // How many Load Buffer have ( Registers for now )
    W_BUFFS =  2,

    step_1 = 4,
    step_2 = 4, 

    SimpleCache4x4 = false , 
    SimpleCache4x8 = true , 

 
  )

}

