// package Data_Reuse

// import chisel3._
// import chisel3.util._

// import freechips.rocketchip.tile._
// import org.chipsalliance.cde.config._
// import freechips.rocketchip.diplomacy._
// import freechips.rocketchip.tile.{BuildRoCC, OpcodeSet}
// import freechips.rocketchip.diplomacy.LazyModule
// import os.truncate
// import firrtl.PrimOps.Add
// import scala.annotation.meta.param
// import freechips.rocketchip.rocket._
// import freechips.rocketchip.tilelink.TLMessages.c
// import freechips.rocketchip.rocket.{TLBConfig, HellaCacheReq} 
// import org.chipsalliance.cde.config.Parameters
// import freechips.rocketchip.amba.axi4._
// import freechips.rocketchip.diplomacy._
// import freechips.rocketchip.subsystem.{CacheBlockBytes, CrossesToOnlyOneClockDomain}
// import freechips.rocketchip.tilelink.{TLBuffer, TLInwardNode, TLToAXI4}
// import chisel3.experimental._

// //my imports
// import Data_Reuse.ChunkUtils._   // import your function from the object
// import Data_Reuse.Data_Reuse_Config


// class DataReuseExample(opcodes: OpcodeSet, val params: DataReuseParams)
//   (implicit p: Parameters) extends LazyRoCC(opcodes = opcodes) {

//   override lazy val module = new DataReuseExampleModuleImpl(this)  

//   val dma = LazyModule(new DmaModule(Data_Reuse_Config.Data_Reuse_Config))
//   //val buffer  = 

//   // tlNode  := TLBuffer(
//   // BufferParams.default,
//   // BufferParams.none,
//   // BufferParams.none,
//   // BufferParams.default,
//   // BufferParams.none) := dma.node  // Connect the memory module to the accelerator’s TileLink node

//   tlNode   := dma.node  // Connect the memory module to the accelerator’s TileLink node

// }

// class DataReuseExampleModuleImpl(outer: DataReuseExample)(implicit p: Parameters) extends LazyRoCCModuleImp(outer) with HasCoreParameters {

//   val params: DataReuseParams = outer.params
//   val dma = outer.dma.module

//   // ROCC interface
//   val cmd = Queue(io.cmd)
//   val funct = cmd.bits.inst.funct
//   val rs1 = cmd.bits.rs1 //address
//   val rs2 = cmd.bits.rs2 //values 


//   //Custom Instructions 
//   val mode_0         = funct === 0.U  // load X address and x_slice dimesnsion 
//   val mode_1         = funct === 1.U  // load w address and Cout dimension 
//   val mode_2         = funct === 2.U  // load O address and  Cin/x_slice value 
//   val mode_3         = funct === 3.U  // load parallel Rin dimesnion and Cin dimension 
//   val mode_4         = funct === 4.U  // select data bit width of input matrices   
//   val mode_5         = funct === 5.U  // load how many loops are needed  
//   val mode_6         = funct === 6.U  // stop busy signal   
//   val mode_7         = funct === 7.U  // load scale factor 
//   val mode_8         = funct === 8.U  // load elements precission  
//   val mode_9         = funct === 9.U  // Performance counters 
//   val mode_10        = funct === 10.U // Start Calcukation  


//   //DMA Module inputs 
//   dma.io.valid     := false.B
//   dma.io.addr      := 0.U
//   dma.io.mode      := 3.U      // inactive  
//   dma.io.writeData := 0.U
//   dma.io.log_S     := log2Ceil(params.DMA_Bytes).U 

//   val DMA_Bits =  params.DMA_Bytes*8 

//   //SyncMem compile parameters  
//   val RowsPerBlock      = ( 1 << (params.WBitWidth - 1) ) / 2  // How many Rows have one SynMem 
//   val totalSyncMems     =  params.x_slice * params.y_slice     //How  many SyncMem the design need to worst case 

//   //How many X_reg will neeed in worst case 
//   val max_x_regs = params.x_slice * (1 << (params.WBitWidth - params.minWeightBits)) //same as total blocks (one X_reg at worst case for every SynMem)

//   val maxParts         = params.XBitWidth / params.minInputBits   // at Worst case one X_reg / SynMem have splitted have maxPart differentt elemtns 
//   val product_bitwidth = (params.XBitWidth/params.minInputBits)*(params.WBitWidth*params.minInputBits)

//   val Products = RegInit(VecInit(Seq.fill(totalSyncMems)(0.U(product_bitwidth.W)))) // Store read results

//   val done          = RegInit(false.B)
//   val Done          = RegInit(false.B)
//   val Done_acc      = RegInit(false.B)
//   val delay         = RegInit(false.B)
//   val delay_counter = RegInit(0.U(2.W))  // Enough to count up to 2

//   val sum    = RegInit(VecInit(Seq.fill(totalSyncMems)(0.S(params.XBitWidth.W))))  // sum in Select Products and Accumulation
//   val DATA_Y = Reg(Vec(totalSyncMems, UInt(product_bitwidth.W)))                   // Store read results
//   val Sign   = Reg(Vec(totalSyncMems, Bool()))                                     // Store the sign as a boolean (true/false) for each BRAM

//   //How many w_reg will neeed in worst case 
//   val max_input_elems_per_reg = params.XBitWidth/params.minInputBits  // X elems in one X_reg in best case 
//   val max_w_elems = max_input_elems_per_reg * max_x_regs              // How many W registers we will neeed in worst case to bring all corresping elemetns (speedup)
//   val buffers  =  params.W_BUFFS 


//   // Create Registers  
//   val X_reg     = RegInit(VecInit(Seq.fill(params.y_slice)(VecInit(Seq.fill(max_x_regs)(0.S(params.XBitWidth.W)))))) // Register for each row of X 
//   val W_reg     = RegInit(VecInit(Seq.fill(params.num_filters)(VecInit(Seq.fill(max_w_elems)(VecInit(Seq.fill(buffers)(0.S(params.WBitWidth.W))))))))    // Register for current column of W for every filter
//   val O_reg     = RegInit(VecInit(Seq.fill(params.num_filters)(VecInit(Seq.fill(params.y_slice)(VecInit(Seq.fill(params.Cout)(0.S(params.OutBitWidth.W))))))))  // Register for Output results

//   //Double Bufferig Parameters 
//   val buffers_mode  = RegInit(VecInit(Seq.fill(buffers)(false.B)))  // 0-> load W ,  1 -> SelectandAccumulate 
//   val buff_elems    = RegInit(VecInit(Seq.fill(buffers)(0.U(log2Ceil(math.max(max_x_regs, params.Cout) + 1).W))))
//   val dirty_elems_w = RegInit(VecInit(Seq.fill(buffers)(0.U(log2Ceil(params.WBitWidth / params.minWeightBits).W))))

//   val load_w_buff_idx  = RegInit(0.U(log2Ceil(buffers).W))
//   val select_buff_idx  = RegInit(0.U(log2Ceil(buffers).W))
//   val w_count          = RegInit(0.U(log2Ceil(params.Cout + 1).W)) // counter to for current Weight matrix Column 

//   //Create BRAMS 
//   val temp_muls_mem = Seq.fill(totalSyncMems) {SyncReadMem(RowsPerBlock  , UInt(product_bitwidth.W))} //FIX THIS
//   val cycleCount_1    = RegInit(0.U(log2Ceil(64 + 1).W)) // Track the current block to write //blocksPerBRAM 
//   val cycleCount_2    = RegInit(0.U(log2Ceil(64 + 1).W)) // Track the current block to write //blocksPerBRAM


//   // Index counters 
//   val w_idx         = RegInit(0.U(log2Ceil(params.Cout + 1).W)) // counter to for current Weight matrix Column 
//   val f_idx         = RegInit(0.U(log2Ceil(params.num_filters  + 1).W)) //counter to track current Weight fildter (NOT USED)   
//   val load_x_cnt    = RegInit(0.U(64.W)) // track the cuurenct x_slice have been loaded [1,Cin/x_slice]
//   val Rin_cnt       = RegInit(0.U(log2Ceil(params.y_slice + 1).W)) //track the current Rin that processed [1,parallel_Rin]
//   val loops_cnt     = RegInit(0.U(64.W)) 

//   //Indexer for Matrices 
//   val i_w           = RegInit(0.U(log2Ceil(params.Cin + 1).W)) 
//   val j_w           = RegInit(0.U(log2Ceil(params.Cout + 1).W)) 
//   val i_x           = RegInit(0.U(64.W)) 
//   val j_x           = RegInit(0.U(log2Ceil(params.Cin + 1).W)) 
//   val i_w_start     = RegInit(0.U((log2Ceil(params.Cin + 1).W))) 
//   val i_x_start     = RegInit(0.U(64.W)) 
//   val j_x_start     = RegInit(0.U(log2Ceil(params.Cout + 1).W)) 
//   val LOOPS         = RegInit(0.U(64.W)) 
//   val i_o           = RegInit(0.U(64.W)) 
//   val j_o           = RegInit(0.U(log2Ceil(params.Cout + 1).W)) 
//   val j_x_temp      = RegInit(0.U(log2Ceil(params.Cin + 1).W)) 
//   val i_w_temp      = RegInit(0.U(log2Ceil(params.Cin + 1).W)) 

//  // Register to keep loops limit at runtime 
//   val XS            =  RegInit(max_x_regs.U(log2Ceil(max_x_regs + 1).W))
//   val XS_W          =  RegInit(max_w_elems.U(log2Ceil(max_w_elems + 1).W))
//   val YS            =  RegInit(params.y_slice.U(log2Ceil(params.y_slice + 1).W))
//   val XS_b          =  RegInit(max_x_regs.U(log2Ceil(max_x_regs + 1).W))
//   val YS_b          =  RegInit(params.y_slice.U(log2Ceil(params.y_slice + 1).W))

//   val elems_per_chunk        = (64/params.OutBitWidth)
//   val done_elems_in_block    =  RegInit(0.U(log2Ceil(elems_per_chunk).W))

//   //Produce register files for method -2 only 
//   val counter_1 = RegInit(0.U(log2Ceil(RowsPerBlock + 2).W))  // Counter to track how many Register Files entries are filled
//   val counter_2 = RegInit(0.U(log2Ceil(RowsPerBlock + 2).W))  // Counter to track how many Register Files entries are filled

//   //Add registers to track the ongoing DMA transaction's mode
//   val dma_send        = RegInit(false.B) //sending DMA requests to A channel on progress
//   val dma_resp        = RegInit(false.B) //receiveving  DMA responces from  D channel on progress
//   val dma_counter_a   = RegInit(0.U(log2Ceil(math.max(max_x_regs, params.Cout) + 1).W))  
//   val dma_counter_d   = RegInit(0.U(log2Ceil(math.max(max_x_regs, params.Cout) + 1).W)) 
  
//   //Select and Accumulte control Signals 
//   val lock            = RegInit(false.B) //send one DMA request to A channel and wait the responce from D channel (muitex)  
//   val READ_ON         = RegInit(false.B)
  
//   // Matrices Addresses
//   val adr_X      =  RegInit(0.U(64.W)) 
//   val adr_W      =  RegInit(0.U(64.W)) 
//   val adr_O      =  RegInit(0.U(64.W)) 
  
//   //Register to save dimension values 
//   val dma_limit             = RegInit(0.U(log2Ceil(params.Cin + 1).W)) //Cin/X_slice
//   val cout_reg              = RegInit(params.Cout.U(log2Ceil(params.Cout + 1).W))
//   val cin_reg               = RegInit(params.Cout.U(log2Ceil(params.Cin + 1).W))
//   val rin_reg               = RegInit(params.Rin.U(log2Ceil(params.Rin + 1).W))
//   val x_slice_Reg           = RegInit(params.x_slice.U(log2Ceil(params.x_slice + 1).W))
//   val y_slice_Reg           = RegInit(params.y_slice.U(log2Ceil(params.y_slice + 1).W))
//   val x_slice_weights_reg   = RegInit(max_w_elems.U(log2Ceil(max_w_elems + 1).W)) // to bring all corresping weights for all x_elemnts  
//   val x_slice_input_reg     = RegInit(max_x_regs.U(log2Ceil(max_x_regs + 1).W)) // so in worst case every sync Mem have hiw own X_reg 


//   // if(params.SCALE){ //SCALE
//     val scale = RegInit(0.U(32.W)) // 32-bit register for IEEE 754 float
//   // }  

//   //bitwidths 
//   val input_bits  = RegInit(0.U(6.W)) //  input bits 
//   val weight_bits = RegInit(0.U(6.W)) //  weights bits 
//   val output_bits = RegInit(0.U(6.W)) //  output bits 

//   // if(params.DEBUG){
//     //Performace counters per state
//     val PC_loadX    =  RegInit(0.U(64.W)) 
//     val PC_Generate =  RegInit(0.U(64.W)) 
//     val PC_loadW    =  RegInit(0.U(64.W)) 
//     val PC_Select   =  RegInit(0.U(64.W)) 
//     val PC_storeO   =  RegInit(0.U(64.W)) 
//     val PC_loadW_and_Select = RegInit(0.U(64.W)) 
//   // }

//   //Dynamic Input Paramters  characteristcs for every w element 
//   val all_available_elems   = RegInit(0.U(log2Ceil(params.Cin + 1).W))                        //new 
//   val elemOffVec            = Reg(Vec(totalSyncMems, UInt(log2Ceil(maxParts).W)))             // Keep in what offset ot row is located the element weight want to read 
//   val w_reg_valid           = Reg(Vec(totalSyncMems, Bool()))                                 // true -> selected value from BRAM is valid   
//   val dirty_elems_x         = RegInit(0.U(log2Ceil(params.XBitWidth/params.minInputBits).W))  //new 
//   val all_available_elems_x = RegInit(0.U(log2Ceil(params.Cout + 1).W))                       //new 
//   val w_elems_per_reg       = RegInit((params.WBitWidth / params.minWeightBits).U)            //How many weight elements fit in one Weight register 
//   val x_elems_per_reg       = RegInit((params.XBitWidth / params.minInputBits).U)             //How many input elements fit  in one input register 

//   //Dynamic Bitwidth 
//   val mask_in                 =  RegInit(0.U(log2Ceil(((1 << params.XBitWidth ) - 1 )  + 1).W))
//   val mask_w                  =  RegInit(0.U(log2Ceil(((1 << params.WBitWidth ) - 1 )  + 1).W))  
//   val mask_p                  =  RegInit(0.U(log2Ceil(((1 << (params.WBitWidth +  params.XBitWidth) ) - 1 )  + 1).W))   
//   val block_rows_1              =  RegInit(0.U(log2Ceil((((1 << (params.WBitWidth  -2 ))) )  + 1).W))
//   val block_rows_2              =  RegInit(0.U(log2Ceil((((1 << (params.WBitWidth  -2 ))) )  + 1).W))
//   val blocks_in_Sync_mem_1      =  RegInit(0.U(log2Ceil((((1 << (params.WBitWidth - params.minWeightBits ))) )  + 1).W))
//   val blocks_in_Sync_mem_2      =  RegInit(0.U(log2Ceil((((1 << (params.WBitWidth - params.minWeightBits ))) )  + 1).W))

//   val chunks_per_Product_bits =  RegInit(0.U(log2Ceil((((params.WBitWidth +  params.XBitWidth) ))  + 1).W))   

//   //indexing extra registers 
//   val mul1 = RegInit(0.U(16.W))
//   val mul2 = RegInit(0.U(16.W))
//   // A channel 
//   val elements_to_read = RegInit(0.U((log2Ceil(max_w_elems) + 1).W))
//   val chunk_addres     = RegInit(0.U(64.W))
//   //D Channel 
//   val elements_to_read_temp = RegInit(0.U((log2Ceil(max_w_elems) + 1).W))  
//   val bytes_to_read         = RegInit(0.U(4.W))
//   val reg_idx_start         = RegInit(0.U((log2Ceil(max_w_elems) + 1).W))  
//   val offset_in_chunk_1     = RegInit(0.U(3.W))
//   val offset_in_chunk_2     = RegInit(0.U(3.W))


//   val step_1 = params.step_1 
//   val totalGroups_1= totalSyncMems / step_1
//   val stepCycle_1 = RegInit(0.U((log2Ceil(totalGroups_1) + 1).W))

//   val step_2 = params.step_2  //TODO  make it work
//   val totalGroups_2= totalSyncMems / step_2
//   val stepCycle_2 = RegInit(0.U((log2Ceil(totalGroups_2) + 1).W))

//   val maxCount = totalSyncMems / step_2  
//   val product_counter = RegInit(0.U(log2Ceil(maxCount + 1).W))


//   // ChunkSignExtender Module 
//   val chunk_nums = maxParts + 2
//   val max_ch =  scala.math.max(step_1, step_2) 
//   val chunkExtenders = Seq.fill(totalSyncMems,chunk_nums) { Module(new ChunkSignExtender(params.XBitWidth))}
//   for {
//     i <- 0 until totalSyncMems
//     j <- 0 until chunk_nums
//   } {
//     val ext = chunkExtenders(i)(j)
//         ext.io.data       := 0.U
//         ext.io.input_bits := 0.U
//         ext.io.mask       := 0.U
//         ext.io.idx        := 0.U
//   }

  
//   // DMA bus parameters ( how many register or elements fitr in 64 bits dma channel)
//    val elemsPerChunk_in = RegInit(0.U(5.W))  // holds up to 16  
//    val RegsPerChunk_in  = RegInit((64 / params.XBitWidth).U(math.max(1, log2Ceil(64 / params.XBitWidth) + 1).W)) 
//    val elemsPerChunk_w  = RegInit(0.U(5.W))  // holds up to 16  
//    val RegsPerChunk_w   = RegInit((64 / params.WBitWidth).U(math.max(1, log2Ceil(64 / params.WBitWidth) + 1).W))

//   //A Chunk Offset Module 
//   val chunkInfoModule_A = Module(new ChunkInfoModule_A(params,max_w_elems))
//   //inputs 
//   chunkInfoModule_A.io.cin_reg          := cin_reg
//   chunkInfoModule_A.io.j_x              := 0.U
//   chunkInfoModule_A.io.x_elems_per_reg  := x_elems_per_reg
//   chunkInfoModule_A.io.elemsPerChunk_in := elemsPerChunk_in
//   chunkInfoModule_A.io.adr_X            := adr_X
//   chunkInfoModule_A.io.RegsPerChunk_in  := RegsPerChunk_in
//   chunkInfoModule_A.io.mul1             := mul1
//   chunkInfoModule_A.io.mul2             := mul2

//   //D Chunk Offset Module 
//   val chunkInfoModule_D = Module(new ChunkInfoModule_D(params,max_w_elems,max_x_regs))
//   //inputs 
//   chunkInfoModule_D.io.cin_reg          := cin_reg
//   chunkInfoModule_D.io.j_x_temp         := 0.U
//   chunkInfoModule_D.io.x_elems_per_reg  := x_elems_per_reg
//   chunkInfoModule_D.io.elemsPerChunk_in := elemsPerChunk_in
//   chunkInfoModule_D.io.RegsPerChunk_in  := RegsPerChunk_in
//   chunkInfoModule_D.io.dma_counter_d    := 0.U
//   chunkInfoModule_D.io.mul1             := mul1
//   chunkInfoModule_D.io.mul2             := mul2


//   // Elaboration time parameters to avoid div(/) and mod(%)
//   val x_slice: Int = params.x_slice  // must be power of 2, e.g. 16
//   val x_slice_mask = (x_slice - 1).U
//   val x_slice_log2 = log2Ceil(x_slice)
//   val max_val = 16 * x_slice
//   val max_mask = (max_val - 1).U


//   // Define states for the FSM
//   val sIdle :: sLoadX :: sGenerateRegFiles :: sLoadW_and_sSelectAndAccumulate :: sStoreOutput :: sDELAY :: Nil = Enum(6)
//   val state = RegInit(sIdle)

//   //If cmd.ready is hardcoded to true.B, the CPU ignores io.busy  SOS 
//   io.busy     := (state =/= sIdle) 
//   cmd.ready   := (state === sIdle)
  
//    switch(state) {
//     is(sIdle) {
//       when(cmd.fire && (mode_0)) {        
//         adr_X         := rs1
//         x_slice_Reg   := rs2

//         //DMA init 
//         dma_send      := true.B
//         dma_resp      := true.B
//         dma_counter_a := 0.U 
//         dma_counter_d := 0.U 

//         //indexer init 
//         i_x       := 0.U 
//         j_x       := 0.U 
//         i_x_start := 0.U 
//         j_x_start := 0.U 
//         loops_cnt := 0.U 
//         i_o       := 0.U 
//         j_o       := 0.U 
//         i_w_temp  := 0.U 
//         j_x_temp  := 0.U 
        
//         // XS YS Registers Init 
//         val mux = Mux(rin_reg >= y_slice_Reg,y_slice_Reg,rin_reg)
//         YS      := mux
//         YS_b    := mux
//         elemsPerChunk_in :=  Mux(input_bits === 8.U , 8.U , 16.U)  
//         elemsPerChunk_w  :=  Mux(weight_bits === 8.U , 8.U , 16.U)  

//         X_reg := VecInit(Seq.fill(params.y_slice)(VecInit(Seq.fill(max_x_regs)(0.S(params.XBitWidth.W)))))
//       } 

//       when(cmd.fire && (mode_1)) {
//         adr_W     := rs1
//         // state     := sLoadX   

//         val scaledSlice        = rs2(15, 0)   // 16 bits
//         x_slice_weights_reg   := rs2(31, 16)  // 16 bits
//         dma_limit             := rs2(47, 32)  // 16 bits

//         val XS_Real        = Mux(cin_reg >= scaledSlice, scaledSlice, cin_reg)
        
//         val elems_per_word = Mux(input_bits === 4.U, params.XBitWidth.U >> 2, params.XBitWidth.U >> 3)
//         val temp_mul       = XS_Real * elems_per_word

//         x_slice_input_reg := scaledSlice
//         XS                := XS_Real
//         XS_b              := XS_Real

//         x_elems_per_reg := elems_per_word // params.XBitWidth.U/input_bits 
//         w_elems_per_reg := Mux(weight_bits === 4.U, params.WBitWidth.U >> 2, params.WBitWidth.U >> 3) //params.WBitWidth.U/weight_bits 

//         //before load X
//         all_available_elems_x := (temp_mul).min(cin_reg)  //( XS_Real * (params.XBitWidth.U/input_bits )).min(cin_reg - j_x) 
//         mul1                  := 0.U
//         mul2                  := temp_mul

//         //dynamic bitwitdh parameters 
//         val p_bits = input_bits + weight_bits
//         mask_in                 := (1.U << input_bits) - 1.U
//         chunks_per_Product_bits := p_bits
//         mask_p                  := (1.U << p_bits) - 1.U
//         mask_w                  := (1.U << weight_bits) - 1.U 

//         if(params.SimpleCache4x8){
//           val block_rows              = Mux(input_bits === 4.U && weight_bits === 8.U,(1.U << (input_bits  -2.U )) ,)(1.U << (weight_bits  -2.U ))  
//         } else { 
//           val block_rows              = (1.U << (weight_bits  -2.U ))  

//         }

//         block_rows_1              :=   block_rows
//         block_rows_2              :=   block_rows


//         if(params.SimpleCache4x8){
//           val blocks_in_Sync_mem  = Mux(input_bits === 4.U && weight_bits === 8.U, 1.U << (params.XBitWidth.U - input_bits ), 1.U << (params.WBitWidth.U - weight_bits ) )
//         } else { 
//           val blocks_in_Sync_mem      = 1.U << (params.WBitWidth.U - weight_bits ) 
//         } 

//         blocks_in_Sync_mem_1 := blocks_in_Sync_mem
//         blocks_in_Sync_mem_2 := blocks_in_Sync_mem

        
//         //input
//         chunkInfoModule_A.io.x_elems_per_reg := elems_per_word
//         chunkInfoModule_A.io.mul1 := 0.U 
//         chunkInfoModule_A.io.mul2 := temp_mul   

//         //output 
//         elements_to_read := chunkInfoModule_A.io.elements_to_read 
//         chunk_addres     := chunkInfoModule_A.io.chunk_address
         
        
//         //input
//         chunkInfoModule_D.io.x_elems_per_reg  := elems_per_word
//         chunkInfoModule_D.io.elemsPerChunk_in := elemsPerChunk_in
//         chunkInfoModule_D.io.RegsPerChunk_in  := RegsPerChunk_in
//         chunkInfoModule_D.io.mul1             := 0.U
//         chunkInfoModule_D.io.mul2             := temp_mul

//         //output 
//         bytes_to_read         :=  chunkInfoModule_D.io.bytes_to_read 
//         reg_idx_start         :=  chunkInfoModule_D.io.reg_idx_start
//         offset_in_chunk_1     :=  chunkInfoModule_D.io.offset_in_chunk_1
//         elements_to_read_temp := chunkInfoModule_D.io.elements_to_read_temp

//       }

//       when(cmd.fire && (mode_2)) {
//         adr_O    := rs1
//         cout_reg := rs2  
//       }

//       when(cmd.fire && (mode_3)) {
//         y_slice_Reg := rs2 
//         cin_reg := rs1 
//       } 
      
//       when(cmd.fire && (mode_5)) {
//         LOOPS   := rs1 
//         rin_reg := rs2
//       }
       
//      if(params.SCALE) { //SCALE  
//       when(cmd.fire && (mode_7)) {
//         scale   := rs1
//       }
//      }

//       when(cmd.fire && (mode_8)) {
//         input_bits   := rs1(5,0)
//         weight_bits  := rs1(11,6)
//         output_bits  := rs1(17,12)

//       if(params.DEBUG){
//         PC_loadX    := 0.U 
//         PC_Generate := 0.U 
//         PC_loadW    := 0.U 
//         PC_Select   := 0.U 
//         PC_storeO   := 0.U 
//       }

//       } 

//       when(cmd.fire && mode_10) { 
//         state := sLoadX
//       }

//     }
//   is(sLoadX) {
//   if(params.DEBUG){  
//     PC_loadX := PC_loadX + 1.U 
//   }
  

//   when(dma_send && !dma.io.busy ) { //send request to DMA in A Channel  
    
//     val j_x_next = j_x + elements_to_read 
    
//     dma.io.mode   := false.B  
//     // dma.io.log_S  :=  log2Ceil(DMA_Bytes).U
//     dma.io.addr   := chunk_addres
//     dma_counter_a := dma_counter_a + elements_to_read            
//     dma.io.valid  := true.B
//     dma_send      := dma_counter_a < all_available_elems_x  - elements_to_read
//     j_x           := j_x_next 


//     chunkInfoModule_A.io.j_x := j_x_next
//     elements_to_read := chunkInfoModule_A.io.elements_to_read 
//     chunk_addres     := chunkInfoModule_A.io.chunk_address

//   }

//   when(dma.io.d_valid) { //response fron DMA in D channel 

//     val j_x_temp_next      = j_x_temp + elements_to_read_temp
//     val dma_counter_d_next = dma_counter_d + elements_to_read_temp

//     val data  = dma.io.readData                                                                                                         // UInt(64.W)
//     val bytes = VecInit(Seq.tabulate(DMA_Bits / params.XBitWidth)(i => data((i + 1) *  params.XBitWidth - 1, i *  params.XBitWidth).asSInt))

//     for (i <- 0 until DMA_Bits / params.XBitWidth) {
//       when(i.U < bytes_to_read) { 
//         X_reg(Rin_cnt)(reg_idx_start + i.U) := bytes(offset_in_chunk_1 + i.U)
//       }
//     }

//     dma_counter_d := dma_counter_d_next
//     dma_resp      := dma_counter_d < all_available_elems_x - elements_to_read_temp
//     j_x_temp      := j_x_temp_next


//     //input 
//     chunkInfoModule_D.io.j_x_temp      := j_x_temp_next
//     chunkInfoModule_D.io.dma_counter_d := dma_counter_d_next

//     //output 
//     bytes_to_read         := chunkInfoModule_D.io.bytes_to_read
//     reg_idx_start         := chunkInfoModule_D.io.reg_idx_start
//     offset_in_chunk_1     := chunkInfoModule_D.io.offset_in_chunk_1
//     elements_to_read_temp := chunkInfoModule_D.io.elements_to_read_temp
//   }

//   when(!dma_resp && !dma_send ) { 
//       dma_send      := true.B && (Rin_cnt < YS -1.U)
//       dma_resp      := true.B && (Rin_cnt < YS -1.U)   
//       dma_counter_a := 0.U 
//       dma_counter_d := 0.U 
//       Rin_cnt       := Rin_cnt + 1.U 
//       j_x           := Mux(Rin_cnt < YS -1.U,j_x_start,j_x)
//       i_x           := Mux(Rin_cnt < YS -1.U,i_x + 1.U,i_x)
//       mul1          := Mux(Rin_cnt < YS -1.U,cin_reg*(i_x + 1.U),mul1)

//       //before load X 
//       val XS_temp   = Mux(cin_reg - j_x_start  >= x_slice_input_reg,x_slice_input_reg,cin_reg - j_x_start )
//       val mul1_temp = (i_x + 1.U) * cin_reg
//       val mul2_temp = XS_temp * x_elems_per_reg

//       XS            := XS_temp
//       mul2          := mul2_temp
//       mul1          := mul1_temp

//       //before load X
//       val bit_offset_in_byte = ((mul1_temp + j_x_start) * input_bits) & (params.XBitWidth.U - 1.U) //( ((i_x * cin_reg) + j_x) * input_bits) %  params.XBitWidth.U
//       val skipInFirstByte = Mux(input_bits === 4.U, bit_offset_in_byte >> 2, bit_offset_in_byte >> 3) //bit_offset_in_byte / input_bits 
//       dirty_elems_x          := skipInFirstByte

//       //++
//       val elems_per_word    = Mux(input_bits === 4.U, params.XBitWidth.U >> 2, params.XBitWidth.U >> 3)
//       all_available_elems_x := (XS * elems_per_word).min(cin_reg - j_x_start)  //( XS * (params.XBitWidth.U/input_bits )).min(cin_reg - j_x) 
//       j_x_temp              := j_x_start

//       chunkInfoModule_A.io.j_x  := j_x_start
//       chunkInfoModule_A.io.mul1 := mul1_temp
//       chunkInfoModule_A.io.mul2 := mul2_temp
//       elements_to_read          := chunkInfoModule_A.io.elements_to_read
//       chunk_addres              := chunkInfoModule_A.io.chunk_address

//       //input
//       chunkInfoModule_D.io.j_x_temp         := j_x_start
//       chunkInfoModule_D.io.mul1             := mul1_temp
//       chunkInfoModule_D.io.mul2             := mul2_temp

//       //output 
//       bytes_to_read         :=  chunkInfoModule_D.io.bytes_to_read 
//       reg_idx_start         :=  chunkInfoModule_D.io.reg_idx_start
//       offset_in_chunk_1     :=  chunkInfoModule_D.io.offset_in_chunk_1
//       elements_to_read_temp := chunkInfoModule_D.io.elements_to_read_temp


//   }

//   when(Rin_cnt === YS){  
//       val x_slice_reg_elems = x_slice_input_reg * x_elems_per_reg
//       load_x_cnt := load_x_cnt + 1.U
//       state      := sGenerateRegFiles
//       j_x_start  := Mux(j_x_start + x_slice_reg_elems   >= cin_reg , 0.U,j_x_start + x_slice_reg_elems )
//       i_x_start  := Mux(j_x_start + x_slice_reg_elems   >= cin_reg , i_x_start + YS -0.U,i_x_start)
//       cycleCount_1 := 0.U
//       Products.foreach(_ := 0.U)
//       stepCycle_1     := 0.U 


//       ////////////////////////////////////////////////////////////////////////////////////
//       val remain_in_column      = cin_reg - i_w
//       val remain_in_column_regs = Mux(w_elems_per_reg === 1.U,remain_in_column,(remain_in_column + 1.U) >> 1)                  // (remain_in_column + w_elems_per_reg -1.U)/w_elems_per_reg 
//       val XS_W_temp             = Mux(remain_in_column_regs >= x_slice_weights_reg,x_slice_weights_reg,remain_in_column_regs)  //max_w_elems
//       XS_W  := XS_W_temp
//       W_reg := VecInit(Seq.fill(params.num_filters)(VecInit(Seq.fill(max_w_elems)(VecInit(Seq.fill(buffers)(0.S(params.WBitWidth.W)))))))  //new 

//       dirty_elems_w.foreach(_ := 0.U)

//       // load_w_buff_idx := 0.U 
//       // select_buff_idx := 0.U 

//       //before load W
//       val temp_mul1 = j_w * cin_reg 
//       val temp_mul2  = XS_W_temp * w_elems_per_reg 
//       mul1 := temp_mul1 
//       mul2 := temp_mul2
//       val bit_offset_in_byte = (((temp_mul1)) * weight_bits) & (params.WBitWidth.U - 1.U)
//       val skipInFirstByte    = bit_offset_in_byte / weight_bits
//       dirty_elems_w(0)    := skipInFirstByte
//       all_available_elems := ( temp_mul2).min(cin_reg - i_w)

//         //input 
//       chunkInfoModule_A.io.j_x              := i_w
//       chunkInfoModule_A.io.x_elems_per_reg  := w_elems_per_reg
//       chunkInfoModule_A.io.elemsPerChunk_in := elemsPerChunk_w
//       chunkInfoModule_A.io.adr_X            := adr_W
//       chunkInfoModule_A.io.RegsPerChunk_in  := RegsPerChunk_w
//       chunkInfoModule_A.io.mul1             := temp_mul1
//       chunkInfoModule_A.io.mul2             := temp_mul2

//       //output 
//       elements_to_read := chunkInfoModule_A.io.elements_to_read
//       chunk_addres     := chunkInfoModule_A.io.chunk_address

//         //input 
//       chunkInfoModule_D.io.j_x_temp         := i_w
//       chunkInfoModule_D.io.x_elems_per_reg  := w_elems_per_reg
//       chunkInfoModule_D.io.elemsPerChunk_in := elemsPerChunk_w
//       chunkInfoModule_D.io.RegsPerChunk_in  := RegsPerChunk_w
//       chunkInfoModule_D.io.mul1             := temp_mul1
//       chunkInfoModule_D.io.mul2             := temp_mul2

//       //output 
//       bytes_to_read         := chunkInfoModule_D.io.bytes_to_read
//       reg_idx_start         := chunkInfoModule_D.io.reg_idx_start
//       offset_in_chunk_2     := chunkInfoModule_D.io.offset_in_chunk_1
//       elements_to_read_temp := chunkInfoModule_D.io.elements_to_read_temp

//       dma_send      := true.B
//       dma_resp      := true.B
//       dma_counter_a := 0.U
//       dma_counter_d := 0.U
//       w_count       := 0.U 
//       i_w_temp      := i_w

//     ////////////////////////////////////////////////////////////////////////////////////////////////////  

//   }

// }
    
// is(sGenerateRegFiles) {
//       if(params.DEBUG){  
//         PC_Generate := PC_Generate + 1.U
//       }
      
// if( step_1 == totalSyncMems ) { 
//       for (sync_mem_idx <- 0 until totalSyncMems) { 
//         // mapping to 2D space 
//         val shiftAmt   = Mux(block_rows_1 === 4.U, 2.U, 6.U)                                                           // 4 = 2^2, 64 = 2^6
//         val start_row  = counter_1 << shiftAmt
         
//         val x_th_x_reg = Mux(blocks_in_Sync_mem_1 === 1.U, (sync_mem_idx.U & x_slice_mask) + counter_1, ((sync_mem_idx.U << 4) + counter_1) & max_mask)
//         val y_th_xreg = Mux(weight_bits === 8.U, sync_mem_idx.U >> x_slice_log2,((sync_mem_idx.U << 4) + counter_1) >> log2Ceil(max_val))

//         when(cycleCount_1 =/= 0.U ) { 
//           val finalAddressInBRAM =  start_row + (cycleCount_1 -1.U)   
//           temp_muls_mem(sync_mem_idx).write(finalAddressInBRAM, Products(sync_mem_idx)) 
//         }
        
//         if(params.SimpleCache4x8){ 
//           val data      =  Mux(input_bits === 4.U && weight_bits === 8.U , (x_th_x_reg.U + 1.U) , X_reg(y_th_xreg)(x_th_x_reg).asUInt)  // width = XBITWIDTH.W
//         } else { 
//           val data      =   X_reg(y_th_xreg)(x_th_x_reg).asUInt  // width = XBITWIDTH.W
//         }

//         val P_data    =   Products(sync_mem_idx) 
//         val P_slices  =   Wire(Vec(maxParts, UInt((product_bitwidth).W)))
          
//         //split 
//         for (i <- 0 until maxParts) {

//           val extender = chunkExtenders(sync_mem_idx)(i)
//           extender.io.data       := data
//           extender.io.input_bits := input_bits
//           extender.io.mask       := mask_in     
//           extender.io.idx        := i.U
//           val signedChunk = extender.io.out

//           val absVal    = signedChunk.abs().asUInt
//           val chunk_p   = (P_data >> (i.U * chunks_per_Product_bits)) & mask_p  // UInt(input_bits.W)
//           val scaled    =  (absVal << 1) 
//           P_slices(i)   := Mux(i.U < x_elems_per_reg , chunk_p + scaled,chunk_p)

//         }

//           val packed = Wire(UInt(product_bitwidth.W))
//           var acc: UInt = 0.U

//         //Concat and Accumulate 
//         for (i <- 0 until maxParts) {
//           val shiftAmt = i.U * chunks_per_Product_bits
//           val shifted  = P_slices(i) << shiftAmt
//           acc = acc | shifted
//         }

//         packed := acc
//         Products(sync_mem_idx) := packed 
//       }   

//       cycleCount_1 := cycleCount_1 + 1.U      

// } else {  

//     for (i <- 0 until step_1) {
//         val sync_mem_idx = stepCycle_1 * step_1.U + i.U
//         val shiftAmt   = Mux(block_rows_1 === 4.U, 2.U, 6.U)
//         val start_row  = counter_1 << shiftAmt
//         val finalAddressInBRAM = start_row + (cycleCount_1 - 1.U)

//         val x_th_x_reg = Mux(
//           blocks_in_Sync_mem_1 === 1.U,
//           (sync_mem_idx & x_slice_mask) + counter_1,
//           ((sync_mem_idx << 4) + counter_1) & max_mask
//         )

//         val y_th_xreg = Mux(
//           weight_bits === 8.U,
//           sync_mem_idx >> x_slice_log2,
//           ((sync_mem_idx << 4) + counter_1) >> log2Ceil(max_val)
//         )

//         // ---------------- WRITE (Must be static indexing) ------------------
//         for (j <- 0 until totalSyncMems) {
//           when(sync_mem_idx === j.U && cycleCount_1 =/= 0.U ) { //&& cycleCount_1 =/= 0.U
//             temp_muls_mem(j).write(finalAddressInBRAM, Products(j))
//           }
//         }

//         // ---------------- DATA LOAD + PROCESS ------------------
//         val data   = X_reg(y_th_xreg)(x_th_x_reg).asUInt
//         val P_data = Products(sync_mem_idx)
//         val P_slices = Wire(Vec(maxParts, UInt(product_bitwidth.W)))

//         for (k <- 0 until maxParts) {
//           val extender = chunkExtenders(i)(k) //use les ectenders now 
//           extender.io.data       := data
//           extender.io.input_bits := input_bits
//           extender.io.mask       := mask_in
//           extender.io.idx        := k.U

//           val signedChunk = extender.io.out
//           val absVal      = signedChunk.abs().asUInt
//           val chunk_p     = (P_data >> (k.U * chunks_per_Product_bits)) & mask_p
//           val scaled      = absVal << 1
//           P_slices(k)     := Mux(k.U < x_elems_per_reg, chunk_p + scaled, chunk_p)
//         }

//         val packed = Wire(UInt(product_bitwidth.W))
//         var acc: UInt = 0.U
//         for (k <- 0 until maxParts) {
//           val shiftAmt = k.U * chunks_per_Product_bits
//           acc = acc | (P_slices(k) << shiftAmt)
//         }

//         packed := acc
//         Products(sync_mem_idx) := packed
//     }


//     when (stepCycle_1 === (totalGroups_1- 1).U ) {
//       stepCycle_1 := 0.U
//       cycleCount_1 := cycleCount_1 + 1.U
//     } .otherwise {
//       stepCycle_1 := stepCycle_1 + 1.U
//     }

// }
//     when(cycleCount_1 === (block_rows_1 -0.U) && stepCycle_1 === (totalGroups_1- 1).U  ) {
//         counter_1    := counter_1 + 1.U
//         cycleCount_1 := 0.U
//         Products.foreach(_ := 0.U)
//     } 
    
//     when(counter_1 === blocks_in_Sync_mem_1 - 1.U && cycleCount_1 === (block_rows_1 ) && stepCycle_1 === (totalGroups_1- 1).U) { //4bits => 7 cycles delay  
//         Rin_cnt       := 0.U
//         j_x           := j_x_start
//         i_x           := i_x_start
//         cycleCount_1  := 0.U
//         counter_1     := 0.U

//         READ_ON       := true.B
//         delay         := true.B
//         delay_counter := 0.U
//         stepCycle_2 := 0.U 

//         state            := sLoadW_and_sSelectAndAccumulate
//     }       
       
//     }
// is(sLoadW_and_sSelectAndAccumulate) {

//   if(params.DEBUG){  
//     PC_loadW_and_Select := PC_loadW_and_Select + 1.U 
//   }  

  
//   when(buffers_mode.reduce(_ || _)) { // Select and accumualte Phase 

//           val buff_index = select_buff_idx //Mux(buffers(0), 0.U, 1.U)

//           if(params.DEBUG){  
//             PC_Select := PC_Select + 1.U 
//           }

// if( step_2 == totalSyncMems ) {  

//         if(params.SimpleCache4x8) { 

//           when(input_bits === 4.U && weight_bits === 8.U) {

//             val index = counter_2 + sync_mem_idx // [0 ,16*XS - 1] 

//             // find block and Memory Block in cahce4_8 made of SyncMems   
//             val w_value = (W_reg(0)(index)(buff_index)).abs().asUInt // 8 bit value -> indicate block Index 
//             val block_index = w_value 
//             val mem_index = block_index >> 4  // val mem_index = block_index / block_per_mem.U
//             val local_block_index = block_index & 15.U // same as block_index % 16.U


//             // find activation element 
//             val y = 0 
//             val x_reg_index  = index >> 1     // Which register (e.g. X_reg(reg_index))  // equivalent to i / 2
//             val x_reg_offset = index & 1.U    // 0 or 1 → first or second element  // equivalent to i % 2 (0 or 1) 
//             val x_val_bits   = Mux(x_reg_offset === 0.U, X_reg(y)(x_reg_index)(3, 0), X_reg(y)(x_reg_index)(7, 4))  
//             val x_val_sint   = x_val_bits.asSInt  // Μετατρέπει τα 4 bits σε signed αριθμό 4-bit
//             val x_val_abs    = Mux(x_val_sint < 0.S, (-x_val_sint).asUInt, x_val_sint.asUInt)

//             //find row in the block  and row in memory  
//             val block_row =  (x_val_abs - 1.U) >> 1 
//             val mem_row = local_block_index << 2 +  block_row

//             val enable_read =  (w_value =/= 0.U && x_val_abs =/= 0.U)  

//             val read_results = VecInit(
//                     temp_muls_mem.zipWithIndex.map { case (mem, idx) =>
//                       mem.read(mem, enable_read && idx.U === mem_index)
//                   }
//                 )

//             val selected_data = read_results(mem_index)    

//           }
         
//       }        
 
//  when(params.SimpleCache4x8 && (input_bits === 8.U || weight_bits === 4.U)) {
//           for (sync_mem_idx <- 0 until totalSyncMems) {
                        
//               ////////////////////////  WEIGHTS //////////////////////////////////
                
//               val x_th_x_reg = Mux(blocks_in_Sync_mem_1 === 1.U, (sync_mem_idx.U & x_slice_mask) + counter_2, ((sync_mem_idx.U << 4) + counter_2) & max_mask)
//               val y_th_xreg = Mux(weight_bits === 8.U, sync_mem_idx.U >> x_slice_log2,((sync_mem_idx.U << 4) + counter_2) >> log2Ceil(max_val))
                
//               val base = x_th_x_reg
//               val w_idx = Mux(x_elems_per_reg === 1.U, base + cycleCount_2, (base << 1) + cycleCount_2)

//               //corresping weight handling 
//               val w_id_in_reg = w_idx + dirty_elems_w(buff_index)                      // if we have some dirty elements in  W_reg vector skip them 
//               val linear_w    = w_id_in_reg
//               val W_reg_Index = Mux(w_elems_per_reg === 1.U, linear_w, linear_w >> 1)  //linear_w / w_elems_per_reg
//               val w_offset    = Mux(w_elems_per_reg === 1.U, 0.U, linear_w(0))         //linear_w % w_elems_per_reg 

//               //corresping weight register  take elem from register //WHY dotn take 0 1 weigths for select 0 1 hmm because is in differnt rows probably 
//               val extender_1 = chunkExtenders(sync_mem_idx)(maxParts)
//               extender_1.io.data       := W_reg(0)(W_reg_Index)(buff_index).asUInt
//               extender_1.io.input_bits := weight_bits
//               extender_1.io.mask       := mask_w
//               extender_1.io.idx        := w_offset
//               val weight_Sint_part = extender_1.io.out

//               val abs_weight_uint  = weight_Sint_part.abs().asUInt

//               //Find row  to read  ->  start_row    = (counter) * block_rows_2  //wherse start in currect SyncMem  so the start of Block i need in this Sync Mem 
//               val shiftAmt     = Mux(block_rows_2 === 4.U, 2.U, 6.U)                                                            // 4 = 2^2, 64 = 2^6
//               val start_row    = counter_2 << shiftAmt
//               val row_in_block = Mux(abs_weight_uint(0) === 0.U, (abs_weight_uint >> 1) -1.U , (abs_weight_uint - 1.U) >> 1)
//               val row_idx      = start_row + row_in_block              

//               //Find offset 
//               val elemOffset = cycleCount_2

//               /////////////////////////// Activations ///////////////////////////////// 

//               val i_th             = row_idx
//               val w_reg_valid_temp = w_idx < buff_elems(buff_index) && abs_weight_uint =/= 0.U

//               val extender = chunkExtenders(sync_mem_idx)(maxParts +  1)
//               extender.io.data       := X_reg(y_th_xreg)(x_th_x_reg).asUInt
//               extender.io.input_bits := input_bits
//               extender.io.mask       := mask_in   
//               extender.io.idx        := elemOffset
//               val sign_X_reg_part = extender.io.out

//               val sign_x       = sign_X_reg_part(input_bits - 1.U)
//               val sign_w       = weight_Sint_part(weight_Sint_part.getWidth - 1)
//               val product_sign = sign_x ^ sign_w // 0 => + | 1 => - 

//               //////////////////////// BRAMs //////////////////////////////////

//               DATA_Y(sync_mem_idx) := RegNext(y_th_xreg)  //the bRAM  you read what Y value has NOT SURE ABOU y_th_reg here 

//               val abs_val     = sign_X_reg_part.abs()
//               val disable     = (abs_weight_uint(0) === 0.U) || !w_reg_valid_temp || (abs_weight_uint === 0.U)
//               val signed_val  = Mux(product_sign === 1.U, -abs_val, abs_val)
//               sum(sync_mem_idx) := RegNext(Mux(disable, 0.S, signed_val))


//               val enable_read = READ_ON && w_reg_valid_temp 
//               val finalAddressInBRAM =  i_th 

//               Products(sync_mem_idx) := temp_muls_mem(sync_mem_idx).read(finalAddressInBRAM,enable_read)  
//               Sign(sync_mem_idx)     := RegNext(product_sign === 0.U) // + True | - False 

//               elemOffVec(sync_mem_idx)  := RegNext(elemOffset)
//               w_reg_valid(sync_mem_idx) := RegNext(w_reg_valid_temp)
//           }
          
//           when (delay_counter === 1.U ){ 
//             delay := false.B 
//           }.otherwise{
//             delay_counter := delay_counter + 1.U 
//           } 

//           when(READ_ON && !Done ) {  //Read values 
//             cycleCount_2 := Mux(cycleCount_2 === x_elems_per_reg - 1.U , 0.U ,cycleCount_2 + 1.U)
//             counter_2    := Mux(cycleCount_2 === x_elems_per_reg - 1.U ,counter_2 + 1.U,counter_2)
//             Done         := Done || (cycleCount_2 === x_elems_per_reg - 1.U  && counter_2 === blocks_in_Sync_mem_2 - 1.U)
//           }

//   } 
// }
// //  else {  
     
// //        for (i <- 0 until step_2) {
// //             val sync_mem_idx =  stepCycle_2 *(step_2.U) + i.U

// //             ////////////////////////  WEIGHTS //////////////////////////////////

// //             val x_th_x_reg = Mux(
// //               blocks_in_Sync_mem_1 === 1.U,
// //               (sync_mem_idx & x_slice_mask) + counter_2,
// //               ((sync_mem_idx << 4) + counter_2) & max_mask
// //             )

// //             val y_th_xreg = Mux(
// //               weight_bits === 8.U,
// //               sync_mem_idx >> x_slice_log2,
// //               ((sync_mem_idx << 4) + counter_2) >> log2Ceil(max_val)
// //             )

// //             val base  = x_th_x_reg
// //             val w_idx = Mux(x_elems_per_reg === 1.U, base + cycleCount_2, (base << 1) + cycleCount_2)

// //             val w_id_in_reg = w_idx + dirty_elems_w(buff_index)
// //             val linear_w    = w_id_in_reg
// //             val W_reg_Index = Mux(w_elems_per_reg === 1.U, linear_w, linear_w >> 1)
// //             val w_offset    = Mux(w_elems_per_reg === 1.U, 0.U, linear_w(0))

// //             val extender_1 = chunkExtenders(i)(maxParts)
// //             extender_1.io.data       := W_reg(0)(W_reg_Index)(buff_index).asUInt
// //             extender_1.io.input_bits := weight_bits
// //             extender_1.io.mask       := mask_w
// //             extender_1.io.idx        := w_offset
// //             val weight_Sint_part = extender_1.io.out

// //             val abs_weight_uint  = weight_Sint_part.abs().asUInt

// //             val shiftAmt     = Mux(block_rows_2 === 4.U, 2.U, 6.U)
// //             val start_row    = counter_2 << shiftAmt
// //             val row_in_block = Mux(abs_weight_uint(0) === 0.U, (abs_weight_uint >> 1) - 1.U, (abs_weight_uint - 1.U) >> 1)
// //             val row_idx      = start_row + row_in_block

// //             val elemOffset = cycleCount_2

// //             /////////////////////////// Activations ///////////////////////////////// 

// //             val i_th             = row_idx
// //             val w_reg_valid_temp = w_idx < buff_elems(buff_index) && abs_weight_uint =/= 0.U

// //             val extender = chunkExtenders(i)(maxParts + 1)
// //             extender.io.data       := X_reg(y_th_xreg)(x_th_x_reg).asUInt
// //             extender.io.input_bits := input_bits
// //             extender.io.mask       := mask_in
// //             extender.io.idx        := elemOffset
// //             val sign_X_reg_part = extender.io.out

// //             val sign_x       = sign_X_reg_part(input_bits - 1.U)
// //             val sign_w       = weight_Sint_part(weight_Sint_part.getWidth - 1)
// //             val product_sign = sign_x ^ sign_w

// //             //////////////////////// BRAMs //////////////////////////////////

// //             DATA_Y(sync_mem_idx) := RegNext(y_th_xreg)

// //             val abs_val     = sign_X_reg_part.abs()
// //             val disable     = (abs_weight_uint(0) === 0.U) || !w_reg_valid_temp || (abs_weight_uint === 0.U)
// //             val signed_val  = Mux(product_sign === 1.U, -abs_val, abs_val)
// //             sum(sync_mem_idx) := RegNext(Mux(disable, 0.S, signed_val))

// //             val enable_read = READ_ON && w_reg_valid_temp
// //             val finalAddressInBRAM = i_th

// //             // // temp_muls_mem must be indexed statically
// //             // for (j <- 0 until totalSyncMems) {
// //             //   val enable_read_new = (sync_mem_idx === j.U)  //&& enable_read
// //             //   // when(sync_mem_idx === j.U && enable_read) {
// //             //     Products(sync_mem_idx) :=  (sync_mem_idx === j.U) //temp_muls_mem(j).read(finalAddressInBRAM,enable_read_new) 
// //             //   // }
// //             // }

// //             // for (j <- 0 until totalSyncMems) {
// //             //   val hit = (sync_mem_idx === j.U)
// //             //   when(hit) {
// //             //     Products(j) := temp_muls_mem(j).read(finalAddressInBRAM,true.B) 
// //             //   }
// //             // }

// //             when(stepCycle_2 === 0.U ) { 
// //               Products(sync_mem_idx) := temp_muls_mem(i).read(finalAddressInBRAM,enable_read) 
// //             }.otherwise { 
// //               Products(sync_mem_idx) := temp_muls_mem(step_2 + i).read(finalAddressInBRAM,enable_read) 
// //             }

// //             Sign(sync_mem_idx) := RegNext(product_sign === 0.U)
// //             elemOffVec(sync_mem_idx) := RegNext(elemOffset)
// //             w_reg_valid(sync_mem_idx) := RegNext(w_reg_valid_temp)
// //           }

// //           stepCycle_2 := Mux(stepCycle_2 === (totalGroups_2 - 1).U, 0.U, stepCycle_2 + 1.U)


// //           when (delay_counter === 1.U ) { 
// //             delay := false.B 
// //           }.otherwise{
// //             delay_counter   := delay_counter + 1.U
// //           } 

// //           when(READ_ON && !Done  && stepCycle_2  === (totalSyncMems/step_2 - 1).U ) {  //Read values 
// //             cycleCount_2 := Mux(cycleCount_2 === x_elems_per_reg - 1.U , 0.U ,cycleCount_2 + 1.U)
// //             counter_2    := 0.U //Mux(cycleCount_2 === x_elems_per_reg - 1.U ,counter_2 + 1.U,counter_2) //            counter_2    := Mux(cycleCount_2 === x_elems_per_reg - 1.U ,counter_2 + 1.U,counter_2)
// //             Done         := Done || (cycleCount_2 === x_elems_per_reg - 1.U  && counter_2 === blocks_in_Sync_mem_2 - 1.U)
// //           }
          
// //  }         

//           when(!delay && !Done_acc && stepCycle_2  === 0.U ) { // Accumulate values ( delay for first value only 1 cycle delay ) 
            
//             // ACCUMULATOR
//             val accum = VecInit((0 until params.y_slice).map { y =>
//               (0 until totalSyncMems).map { i => 

//                 val offset          = elemOffVec(i)
//                 val w_reg_valid_tmp = w_reg_valid(i)
//                 val valid_read      = Mux(w_reg_valid_tmp,Products(i),0.U(Products(i).getWidth.W))

//                   //kepp from row per block the correct data
//                       val readDataVec_part = ( valid_read  >> (offset * chunks_per_Product_bits)) & mask_p  // UInt(input_bits.W)

//                       val unsigned_clean = Mux1H(Seq(
//                       // (chunks_per_Product_bits ===  6.U)  -> readDataVec_part(5, 0),    //  2+4 = 6 bits
//                       // (chunks_per_Product_bits === 10.U)  -> readDataVec_part(9, 0),    //  2+8 = 10 bits
//                       (chunks_per_Product_bits ===  8.U)  -> readDataVec_part(7, 0),    //  4+4 = 8 bits
//                       (chunks_per_Product_bits === 12.U)  -> readDataVec_part(11, 0),   //  4+8 =12 bits
//                       (chunks_per_Product_bits === 16.U)  -> readDataVec_part(15, 0),   //  8+8 =16 bits
//                     ))

//                     val readDataVec_part_sign = unsigned_clean.zext.asSInt
//                     val signedValue = Mux(Sign(i), readDataVec_part_sign - sum(i),  - readDataVec_part_sign - sum(i)) 

//                     Mux(DATA_Y(i) === y.U  , signedValue, 0.S(product_bitwidth.W)) 
                  
//               }.reduce(_ + _)  // Add all the results for each `i`
              
//             })

//             // Now update O_reg for each y slice location
//             for (y <- 0 until params.y_slice) {
//               O_reg(0)(y)(w_idx - 0.U) := O_reg(0)(y)(w_idx - 0.U) + accum(y)
//             }

//             Done_acc := RegNext(Done) 
//         }  

//     }
   
//   when(Done_acc && w_idx =/= cout_reg) { // select next Phase 
         
//           Products.foreach(_ := 0.U) 
//           cycleCount_2 := 0.U
//           counter_2    := 0.U
//           w_idx      := Mux(w_idx === cout_reg,0.U,w_idx +  params.w_slice.U)
          
//           //new 
//           READ_ON       := true.B
//           delay         := true.B
//           delay_counter := 0.U

//           dirty_elems_w(select_buff_idx) := 0.U
//           buff_elems(select_buff_idx)    := 0.U
//           Done                           := false.B
//           Done_acc                       := false.B
//           buffers_mode(select_buff_idx)  := false.B
//           select_buff_idx                := select_buff_idx + 1.U
          
//     }.elsewhen(w_idx === cout_reg) { 

//       when(load_x_cnt >= dma_limit) { 
//                 i_w        := 0.U
//                 i_w_start  := 0.U
//                 load_x_cnt := 0.U
//                 Rin_cnt    := 0.U
//                 state      := sStoreOutput
//               }.otherwise{
//                 val XS_temp   = Mux(cin_reg - j_x  >= x_slice_input_reg,x_slice_input_reg,cin_reg - j_x )
//                 val mul1_temp = i_x * cin_reg
//                 val mul2_temp = XS_temp * x_elems_per_reg

//                 i_w           := i_w_start + mul2_temp
//                 i_w_start     := i_w_start + mul2_temp
//                 XS            := XS_temp
//                 X_reg         := VecInit(Seq.fill(params.y_slice)(VecInit(Seq.fill(max_x_regs)(0.S(params.XBitWidth.W)))))
//                 dma_counter_a := 0.U
//                 dma_counter_d := 0.U
//                 mul2          := mul2_temp
//                 mul1          := mul1_temp

//                 //before load X
//                 val bit_offset_in_byte = ((mul1_temp + j_x) * input_bits) & (params.XBitWidth.U - 1.U) //( ((i_x * cin_reg) + j_x) * input_bits) %  params.XBitWidth.U
//                 val skipInFirstByte = Mux(input_bits === 4.U, bit_offset_in_byte >> 2, bit_offset_in_byte >> 3) //bit_offset_in_byte / input_bits 
//                 dirty_elems_x          := skipInFirstByte

//                 //++
//                 val elems_per_word    = Mux(input_bits === 4.U, params.XBitWidth.U >> 2, params.XBitWidth.U >> 3)
//                 all_available_elems_x := (XS * elems_per_word).min(cin_reg - j_x)  //( XS * (params.XBitWidth.U/input_bits )).min(cin_reg - j_x) 
//                 j_x_temp              := j_x

//                 //new
//                 // val (elements_to_read_a,chunk_address_a) =  calcChunkInfo_A(cin_reg,j_x,x_elems_per_reg,elemsPerChunk_in,adr_X,RegsPerChunk_in,mul1_temp,mul2_temp)
//                 // elements_to_read := elements_to_read_a
//                 // chunk_addres     := chunk_address_a 

//                 chunkInfoModule_A.io.j_x  := j_x
//                 chunkInfoModule_A.io.mul1 := mul1_temp
//                 chunkInfoModule_A.io.mul2 := mul2_temp
//                 elements_to_read          := chunkInfoModule_A.io.elements_to_read
//                 chunk_addres              := chunkInfoModule_A.io.chunk_address

//                 // val (bytes_to_read_d,reg_idx_start_d,offset_in_chunk_1_d,elements_to_read_temp_d) = calcChunkInfo_D(cin_reg,j_x,x_elems_per_reg,elemsPerChunk_in,RegsPerChunk_in,0.U,mul1_temp,mul2_temp)
//                 // bytes_to_read         :=  bytes_to_read_d 
//                 // reg_idx_start         :=  reg_idx_start_d
//                 // offset_in_chunk_1     := offset_in_chunk_1_d
//                 // elements_to_read_temp := elements_to_read_temp_d 

//                 //input
//                 chunkInfoModule_D.io.j_x_temp         := j_x
//                 chunkInfoModule_D.io.mul1             := mul1_temp
//                 chunkInfoModule_D.io.mul2             := mul2_temp

//                 //output 
//                 bytes_to_read         :=  chunkInfoModule_D.io.bytes_to_read 
//                 reg_idx_start         :=  chunkInfoModule_D.io.reg_idx_start
//                 offset_in_chunk_1     :=  chunkInfoModule_D.io.offset_in_chunk_1
//                 elements_to_read_temp := chunkInfoModule_D.io.elements_to_read_temp

//                 state := sLoadX


//       }
//           j_w              := 0.U
//           w_idx            := 0.U
//           cycleCount_2       := 0.U
//           counter_2        := 0.U
//           Done             := false.B
//           Done_acc         := false.B
//           buff_elems.foreach(_ := 0.U)
//           // select_buff_idx  := 0.U
//           // load_w_buff_idx  := 0.U
//           lock             := false.B
         
//       }

// }

// is(sStoreOutput) {
//       if(params.DEBUG){  
//         PC_storeO := PC_storeO + 1.U
//       }

//       val remaining_elems = cout_reg - dma_counter_d  // Elements left in the row
//       val R_elems_per_chunk = ((elems_per_chunk.U - done_elems_in_block).min(remaining_elems)) 
//       val linear_index  = i_o * cout_reg + j_o  
//       val chunk_index   = linear_index / ((elems_per_chunk.U)) //.min(remaining_elems))   // Which chunk (64-bit block)
//       val chunk_address = adr_O + (chunk_index * 8.U) 

//       when(dma_send && !dma.io.busy && !lock) { //send request to DMA in A Channel 
//         dma.io.mode := true.B   
//         // dma.io.log_S  := log2Ceil(DMA_Bytes).U
      
//       //NO Scale    
//         val data_chunk = (0 until elems_per_chunk).foldLeft(0.U(64.W)) { (acc, i) =>
//             acc | Mux(i.U < R_elems_per_chunk, (O_reg(0)(Rin_cnt)(dma_counter_a + i.U) ).asUInt()  << ((i.U + done_elems_in_block)* params.OutBitWidth.U), 0.U(64.W)) 
//         } 
      
//        //YES Scale   
//       //  val scaleModule = Module(new Scale_Vector) 
//       //  val dataVector = VecInit((0 until elems_per_chunk).map(i => Mux(i.U < R_elems_per_chunk, O_reg(0)(Rin_cnt)(dma_counter_a + i.U), 0.S(64.W))))
//       //  scaleModule.io.inVector := dataVector 
//       //  scaleModule.io.scale    := scale 
    
//         // Option 2: Building the mask per byte lane (define beatBytes as total byte lanes in the beat)
//         val beatBytes = 8  // Total number of byte lanes in a 64-bit word
//         val bytesPerElem = params.OutBitWidth.U >> 3  // Divide by 8
//         val startByte = done_elems_in_block * bytesPerElem
//         val endByte   = startByte + (R_elems_per_chunk * bytesPerElem) //R_elems_per_chunk
//         dma.io.mask := Cat((0 until beatBytes).map { i => (i.U >= startByte) && (i.U < endByte) }.reverse)

//         // dma.io.writeData := scaleModule.io.out  // YES SCALE 
//            dma.io.writeData :=  data_chunk        // NO Scale  

//         dma.io.addr   := chunk_address
//         dma.io.valid  := true.B
//         dma_counter_a := dma_counter_a + R_elems_per_chunk
//         dma_send      := dma_counter_a < cout_reg - R_elems_per_chunk
//         dma.io.valid  := true.B

//         for (i <- 0 until elems_per_chunk) {
//           when(i.U < R_elems_per_chunk) {
//               O_reg(0)(Rin_cnt)(dma_counter_a + i.U) := 0.S 
//           }
//         }

//         lock    := true.B 
//         j_o := j_o + R_elems_per_chunk 

//       }

//       when(dma.io.d_valid) { //response fron DMA in D channel   
//         dma_counter_d := dma_counter_d + R_elems_per_chunk 
//         dma_resp := dma_counter_d < cout_reg - R_elems_per_chunk 
//         lock    := false.B 
//         done_elems_in_block := Mux(done_elems_in_block === (elems_per_chunk.U - 1.U), 0.U, done_elems_in_block + R_elems_per_chunk)
//       }
 
//       when(!dma_send && !dma_resp && !(Rin_cnt === YS)) {  
//         Rin_cnt       := Rin_cnt + 1.U
//         dma_counter_d := 0.U
//         dma_counter_a := 0.U
//         j_o           := 0.U
//         i_o           := i_o + 1.U
//         dma_send      := true.B && (Rin_cnt < YS -1.U)
//         dma_resp      := true.B && (Rin_cnt < YS -1.U)
//       } 

//       when(Rin_cnt === YS) {
//          when(loops_cnt === LOOPS -1.U){
//             Rin_cnt             := 0.U
//             state               := sDELAY
//             done_elems_in_block := 0.U

//          }.otherwise{
//             loops_cnt     := loops_cnt + 1.U
//             dma_send      := true.B
//             dma_resp      := true.B
//             dma_counter_a := 0.U
//             dma_counter_d := 0.U
//             X_reg         := VecInit(Seq.fill(params.y_slice)(VecInit(Seq.fill(max_x_regs)(0.S(params.XBitWidth.W)))))
//             Rin_cnt       := 0.U

//             //new
//             val XS_temp = Mux(cin_reg >= x_slice_input_reg,x_slice_input_reg,cin_reg)
//             XS := XS_temp

//             //new
//             val remain_in_column =  rin_reg - i_x 
//             YS :=  Mux(remain_in_column >= y_slice_Reg,y_slice_Reg,remain_in_column)
            
//             dma.io.mask := ((1.U << (R_elems_per_chunk * params.OutBitWidth.U)) - 1.U) << (done_elems_in_block * params.OutBitWidth.U) //new
//             state := sLoadX

//             //before load X
//             val bit_offset_in_byte = (((i_x * cin_reg) + j_x) * input_bits) & (params.XBitWidth.U - 1.U) //( ((i_x * cin_reg) + j_x) * input_bits) %  params.XBitWidth.U
//             val skipInFirstByte = Mux(input_bits === 4.U, bit_offset_in_byte >> 2, bit_offset_in_byte >> 3) //bit_offset_in_byte / input_bits 
//             dirty_elems_x           := skipInFirstByte
//             val elems_per_word = Mux(input_bits === 4.U, params.XBitWidth.U >> 2, params.XBitWidth.U >> 3)
//             all_available_elems_x := (XS * elems_per_word).min(cin_reg - j_x) //( XS * (params.XBitWidth.U/input_bits )).min(cin_reg - j_x) 
//             j_x_temp := j_x 

//          }

//         }
//       }
//       is(sDELAY) {
//           io.busy     := false.B  
//           cmd.ready   := true.B 
//         when(cmd.fire && (mode_6)) {
//           state := sIdle 
//         }

//       }


      
          
      
//   } 

//   val counter_p = RegInit(0.U(5.W)) // Declare outside to preserve value

//   if(params.DEBUG) {   
//   when(cmd.fire && (mode_9)) {
      
//         io.resp.valid := cmd.valid
//         io.resp.bits.rd := cmd.bits.inst.rd          
//         io.resp.bits.data := MuxLookup(counter_p, 0.U, Array(
//             0.U -> PC_loadX,
//             1.U -> PC_Generate,
//             2.U -> PC_loadW,
//             3.U -> PC_Select,
//             4.U -> PC_storeO,
//             5.U -> PC_loadW_and_Select
//         ))

//         counter_p := counter_p + 1.U
//       } 
// }

//   when( ( buffers_mode.map(! _).reduce(_ || _)  && w_count =/= cout_reg ) && (state === sLoadW_and_sSelectAndAccumulate || state === sGenerateRegFiles)   ) { // Load W Phase 
      
//       val buff_index = load_w_buff_idx 
//       if(params.DEBUG){  
//         PC_loadW := PC_loadW + 1.U 
//       }  
      
//       when(dma_send && (!dma.io.busy)) { // send request to DMA in A Channel  
        
//         val i_w_next = i_w + elements_to_read 

//         dma.io.mode   := false.B  
//         // dma.io.log_S  := log2Ceil(DMA_Bytes).U
//         dma.io.addr   := chunk_addres 
//         dma_counter_a := dma_counter_a + elements_to_read
//         dma.io.valid  := true.B
//         dma_send      := dma_counter_a < all_available_elems - elements_to_read 
//         i_w           := i_w_next 
         
//         //input 
//         chunkInfoModule_A.io.j_x              := i_w_next
//         chunkInfoModule_A.io.x_elems_per_reg  := w_elems_per_reg
//         chunkInfoModule_A.io.elemsPerChunk_in := elemsPerChunk_w
//         chunkInfoModule_A.io.adr_X            := adr_W
//         chunkInfoModule_A.io.RegsPerChunk_in  := RegsPerChunk_w

//         //output
//         elements_to_read := chunkInfoModule_A.io.elements_to_read 
//         chunk_addres     := chunkInfoModule_A.io.chunk_address
//       }

//       when(dma.io.d_valid) { // response from DMA in D channel   
//         val i_w_temp_next      = i_w_temp + elements_to_read_temp
//         val dma_counter_d_next = dma_counter_d + elements_to_read_temp

//         val data  = dma.io.readData  // UInt(64.W)
//         val bytes = VecInit(Seq.tabulate(DMA_Bits / params.WBitWidth)(i => data((i + 1) * params.WBitWidth - 1, i * params.WBitWidth).asSInt))
        
//         for (i <- 0 until DMA_Bits / params.WBitWidth) {
//           when(i.U < bytes_to_read ) {
//             W_reg(f_idx)(reg_idx_start + i.U)(buff_index) := bytes(offset_in_chunk_2 + i.U)
//           }
//         }
//         dma_counter_d := dma_counter_d_next
//         dma_resp      := dma_counter_d < all_available_elems - elements_to_read_temp
//         i_w_temp      := i_w_temp_next

//         //input 
//         chunkInfoModule_D.io.j_x_temp         := i_w_temp_next
//         chunkInfoModule_D.io.x_elems_per_reg  := w_elems_per_reg
//         chunkInfoModule_D.io.elemsPerChunk_in := elemsPerChunk_w
//         chunkInfoModule_D.io.RegsPerChunk_in  := RegsPerChunk_w
//         chunkInfoModule_D.io.dma_counter_d    := dma_counter_d_next

//         //output 
//         bytes_to_read         :=  chunkInfoModule_D.io.bytes_to_read 
//         reg_idx_start         :=  chunkInfoModule_D.io.reg_idx_start
//         offset_in_chunk_2     :=  chunkInfoModule_D.io.offset_in_chunk_1
//         elements_to_read_temp := chunkInfoModule_D.io.elements_to_read_temp
        
//       }
      
          
//       when(!dma_resp && !dma_send) { //!dma_resp && !dma_send
//         i_w                      := i_w_start
//         j_w                      := j_w + 1.U
//         f_idx                    := 0.U
//         dma_counter_a            := 0.U
//         dma_send                 := true.B
//         dma_resp                 := true.B
//         lock                     := false.B
//         buff_elems(buff_index)   := dma_counter_d
//         dma_counter_d            := 0.U
//         buffers_mode(buff_index) := true.B

//         ///next W elements 
//         val remain_in_column_regs = (cin_reg - i_w_start  + w_elems_per_reg -1.U)/w_elems_per_reg
//         val XS_W_temp             = Mux(remain_in_column_regs >= x_slice_weights_reg,x_slice_weights_reg,remain_in_column_regs)
//         XS_W := XS_W_temp 
//         ///next W elements 

//         load_w_buff_idx := load_w_buff_idx + 1.U //Mux( load_w_buff_idx === (buffers - 1).U ,load_w_buff_idx + 1.U,0.U)
//         w_count         := w_count + 1.U
 
//         //before load W
//         val temp_mul1 = (j_w + 1.U) * cin_reg 
//         val temp_mul2  = XS_W_temp * w_elems_per_reg 

//         mul1 := temp_mul1 
//         mul2 := temp_mul2

//         val bit_offset_in_byte = (((temp_mul1) + i_w_start) * weight_bits) & (params.WBitWidth.U - 1.U)
//         val skipInFirstByte    = bit_offset_in_byte / weight_bits 
//         dirty_elems_w(0.U)     := skipInFirstByte //fix this  //load_w_buff_idx + 1.U
//         all_available_elems    := ( temp_mul2).min(cin_reg - i_w_start) 
//         i_w_temp               := i_w_start
 
//         chunkInfoModule_A.io.j_x              := i_w_start 
//         chunkInfoModule_A.io.x_elems_per_reg  := w_elems_per_reg
//         chunkInfoModule_A.io.elemsPerChunk_in := elemsPerChunk_w
//         chunkInfoModule_A.io.adr_X            := adr_W
//         chunkInfoModule_A.io.RegsPerChunk_in  := RegsPerChunk_w
//         chunkInfoModule_A.io.mul1             := temp_mul1
//         chunkInfoModule_A.io.mul2             := temp_mul2

//         elements_to_read          := chunkInfoModule_A.io.elements_to_read
//         chunk_addres              := chunkInfoModule_A.io.chunk_address


//         //input 
//         chunkInfoModule_D.io.j_x_temp         := i_w_start 
//         chunkInfoModule_D.io.x_elems_per_reg  := w_elems_per_reg
//         chunkInfoModule_D.io.elemsPerChunk_in := elemsPerChunk_w
//         chunkInfoModule_D.io.RegsPerChunk_in  := RegsPerChunk_w
//         chunkInfoModule_D.io.mul1             := temp_mul1
//         chunkInfoModule_D.io.mul2             := temp_mul2

//         //output 
//         bytes_to_read         := chunkInfoModule_D.io.bytes_to_read
//         reg_idx_start         := chunkInfoModule_D.io.reg_idx_start
//         offset_in_chunk_2     := chunkInfoModule_D.io.offset_in_chunk_1
//         elements_to_read_temp := chunkInfoModule_D.io.elements_to_read_temp

//       } 
//   } 


// }

   

// class WithDataReuseAccelerator extends Config((site, here, up) => {
//   case BuildRoCC => Seq(
//     (p: Parameters) => {
//       implicit val implicitParams: Parameters = p
//       implicit val valName: ValName = ValName("MatMul_Data_Reuse_example")

//       // Pass fbus to DataReuseExample
//       LazyModule(
//         new DataReuseExample(
//           opcodes = OpcodeSet.all,            // Opcode used for the accelerator
//           params  = Data_Reuse_Config.Data_Reuse_Config  // Use the config from the LinearFilterConfig object
//         ) {
  
//         }
//       )
//     }
//   )
// }) 


package Data_Reuse

import chisel3._
import chisel3.util._

import freechips.rocketchip.tile._
import org.chipsalliance.cde.config._
import freechips.rocketchip.diplomacy._
import freechips.rocketchip.tile.{BuildRoCC, OpcodeSet}
import freechips.rocketchip.diplomacy.LazyModule
import os.truncate
import firrtl.PrimOps.Add
import scala.annotation.meta.param
import freechips.rocketchip.rocket._
import freechips.rocketchip.tilelink.TLMessages.c
import freechips.rocketchip.rocket.{TLBConfig, HellaCacheReq} 
import org.chipsalliance.cde.config.Parameters
import freechips.rocketchip.amba.axi4._
import freechips.rocketchip.diplomacy._
import freechips.rocketchip.subsystem.{CacheBlockBytes, CrossesToOnlyOneClockDomain}
import freechips.rocketchip.tilelink.{TLBuffer, TLInwardNode, TLToAXI4}
import chisel3.experimental._

//my imports
import Data_Reuse.ChunkUtils._   // import your function from the object
import Data_Reuse.Data_Reuse_Config


class DataReuseExample(opcodes: OpcodeSet, val params: DataReuseParams)
  (implicit p: Parameters) extends LazyRoCC(opcodes = opcodes) {

  override lazy val module = new DataReuseExampleModuleImpl(this)  

  val dma = LazyModule(new DmaModule(Data_Reuse_Config.Data_Reuse_Config))
  //val buffer  = 

  // tlNode  := TLBuffer(
  // BufferParams.default,
  // BufferParams.none,
  // BufferParams.none,
  // BufferParams.default,
  // BufferParams.none) := dma.node  // Connect the memory module to the accelerator’s TileLink node

  tlNode   := dma.node  // Connect the memory module to the accelerator’s TileLink node

}

class DataReuseExampleModuleImpl(outer: DataReuseExample)(implicit p: Parameters) extends LazyRoCCModuleImp(outer) with HasCoreParameters {

  val params: DataReuseParams = outer.params
  val dma = outer.dma.module

  // ROCC interface
  val cmd = Queue(io.cmd)
  val funct = cmd.bits.inst.funct
  val rs1 = cmd.bits.rs1 //address
  val rs2 = cmd.bits.rs2 //values 


  //Custom Instructions 
  val mode_0         = funct === 0.U  // load X address and x_slice dimesnsion 
  val mode_1         = funct === 1.U  // load w address and Cout dimension 
  val mode_2         = funct === 2.U  // load O address and  Cin/x_slice value 
  val mode_3         = funct === 3.U  // load parallel Rin dimesnion and Cin dimension 
  val mode_4         = funct === 4.U  // select data bit width of input matrices   
  val mode_5         = funct === 5.U  // load how many loops are needed  
  val mode_6         = funct === 6.U  // stop busy signal   
  val mode_7         = funct === 7.U  // load scale factor 
  val mode_8         = funct === 8.U  // load elements precission  
  val mode_9         = funct === 9.U  // Performance counters 
  val mode_10        = funct === 10.U // Start Calcukation  


  //DMA Module inputs 
  dma.io.valid     := false.B
  dma.io.addr      := 0.U
  dma.io.mode      := 3.U      // inactive  
  dma.io.writeData := 0.U
  dma.io.log_S     := log2Ceil(params.DMA_Bytes).U 

  //SyncMem compile parameters  
  val RowsPerBlock      = ( 1 << (params.WBitWidth - 1) ) / 2  // How many Rows have one SynMem 
  val totalSyncMems     =  params.x_slice * params.y_slice     //How  many SyncMem the design need to worst case 

  //How many X_reg will neeed in worst case 
  val max_x_regs = params.x_slice * (1 << (params.WBitWidth - params.minWeightBits)) //same as total blocks (one X_reg at worst case for every SynMem)

  val maxParts         = params.XBitWidth / params.minInputBits   // at Worst case one X_reg / SynMem have splitted have maxPart differentt elemtns 
  val product_bitwidth = (params.XBitWidth/params.minInputBits)*(params.WBitWidth*params.minInputBits)

  val Products = RegInit(VecInit(Seq.fill(totalSyncMems)(0.U(product_bitwidth.W)))) // Store read results

  val done          = RegInit(false.B)
  val Done          = RegInit(false.B)
  val Done_acc      = RegInit(false.B)
  val delay         = RegInit(false.B)
  val delay_counter = RegInit(0.U(2.W))  // Enough to count up to 2

  val sum    = RegInit(VecInit(Seq.fill(totalSyncMems)(0.S(params.XBitWidth.W))))  // sum in Select Products and Accumulation
  val DATA_Y = Reg(Vec(totalSyncMems, UInt(product_bitwidth.W)))                   // Store read results
  val Sign   = Reg(Vec(totalSyncMems, Bool()))                                     // Store the sign as a boolean (true/false) for each BRAM 

  // val max_w_elems = max_x_regs //FIX THIS 

  //How many w_reg will neeed in worst case 
  val max_input_elems_per_reg = params.XBitWidth/params.minInputBits  // X elems in one X_reg in best case 
  val max_w_elems = max_input_elems_per_reg * max_x_regs              // How many W registers we will neeed in worst case to bring all corresping elemetns (speedup)
  val buffers  =  params.W_BUFFS 


  // Create Scratchpad Memory (Registers)  
  val X_reg     = RegInit(VecInit(Seq.fill(params.y_slice)(VecInit(Seq.fill(max_x_regs)(0.S(params.XBitWidth.W)))))) // Register for each row of X 
  val W_reg     = RegInit(VecInit(Seq.fill(params.num_filters)(VecInit(Seq.fill(max_w_elems)(VecInit(Seq.fill(buffers)(0.S(params.WBitWidth.W))))))))    // Register for current column of W for every filter
  val O_reg     = RegInit(VecInit(Seq.fill(params.num_filters)(VecInit(Seq.fill(params.y_slice)(VecInit(Seq.fill(params.Cout)(0.S(params.OutBitWidth.W))))))))  // Register for Output results

//  if(params.SimpleCache4x8){ 
    //Cache_4_8 Register mode 
    val Cache_4_8 = RegInit(VecInit(
      (1 to 128).map { w =>
        VecInit(Seq(2, 4, 6, 8).map { x =>
          (w * x).U(12.W)
        })
      }
    ))
//  }  

 val start_base = RegInit(0.U(log2Ceil(max_w_elems.toInt + 1).W))

  //Double Bufferig Parameters 
  val buffers_mode  = RegInit(VecInit(Seq.fill(buffers)(false.B)))  // 0-> load W ,  1 -> SelectandAccumulate 
  val buff_elems    = RegInit(VecInit(Seq.fill(buffers)(0.U(log2Ceil(math.max(max_x_regs, params.Cout) + 1).W))))
  val dirty_elems_w = RegInit(VecInit(Seq.fill(buffers)(0.U(log2Ceil(params.WBitWidth / params.minWeightBits).W))))

  val load_w_buff_idx  = RegInit(0.U(log2Ceil(buffers).W))
  val select_buff_idx  = RegInit(0.U(log2Ceil(buffers).W))
  val w_count          = RegInit(0.U(log2Ceil(params.Cout + 1).W)) // counter to for current Weight matrix Column 

  //Create BRAMS 
  val temp_muls_mem = Seq.fill(totalSyncMems) {SyncReadMem(RowsPerBlock  , UInt(product_bitwidth.W))} //FIX THIS
  val cycleCount_1    = RegInit(0.U(log2Ceil(64 + 1).W)) // Track the current block to write //blocksPerBRAM 
  val cycleCount_2    = RegInit(0.U(log2Ceil(64 + 1).W)) // Track the current block to write //blocksPerBRAM


  // Index counters 
  val w_idx         = RegInit(0.U(log2Ceil(params.Cout + 1).W)) // counter to for current Weight matrix Column 
  val f_idx         = RegInit(0.U(log2Ceil(params.num_filters  + 1).W)) //counter to track current Weight fildter (NOT USED)   
  val load_x_cnt    = RegInit(0.U(64.W)) // track the cuurenct x_slice have been loaded [1,Cin/x_slice]
  val Rin_cnt       = RegInit(0.U(log2Ceil(params.y_slice + 1).W)) //track the current Rin that processed [1,parallel_Rin]
  val loops_cnt     = RegInit(0.U(64.W)) 

  //Indexer for Matrices 
  val i_w           = RegInit(0.U(log2Ceil(params.Cin + 1).W)) 
  val j_w           = RegInit(0.U(log2Ceil(params.Cout + 1).W)) 
  val i_x           = RegInit(0.U(64.W)) 
  val j_x           = RegInit(0.U(log2Ceil(params.Cin + 1).W)) 
  val i_w_start     = RegInit(0.U((log2Ceil(params.Cin + 1).W))) 
  val i_x_start     = RegInit(0.U(64.W)) 
  val j_x_start     = RegInit(0.U(log2Ceil(params.Cout + 1).W)) 
  val LOOPS         = RegInit(0.U(64.W)) 
  val i_o           = RegInit(0.U(64.W)) 
  val j_o           = RegInit(0.U(log2Ceil(params.Cout + 1).W)) 
  val j_x_temp      = RegInit(0.U(log2Ceil(params.Cin + 1).W)) 
  val i_w_temp      = RegInit(0.U(log2Ceil(params.Cin + 1).W)) 

 // Register to keep loops limit at runtime 
  val XS            =  RegInit(max_x_regs.U(log2Ceil(max_x_regs + 1).W))
  val XS_W          =  RegInit(max_w_elems.U(log2Ceil(max_w_elems + 1).W))
  val YS            =  RegInit(params.y_slice.U(log2Ceil(params.y_slice + 1).W))
  val XS_b          =  RegInit(max_x_regs.U(log2Ceil(max_x_regs + 1).W))
  val YS_b          =  RegInit(params.y_slice.U(log2Ceil(params.y_slice + 1).W))

  val elems_per_chunk        = (64/params.OutBitWidth)
  val done_elems_in_block    =  RegInit(0.U(log2Ceil(elems_per_chunk).W))

  //Produce register files for method -2 only 
  val counter_1 = RegInit(0.U(log2Ceil(RowsPerBlock + 2).W))  // Counter to track how many Register Files entries are filled
  val counter_2 = RegInit(0.U(log2Ceil(RowsPerBlock + 2).W))  // Counter to track how many Register Files entries are filled

  //Add registers to track the ongoing DMA transaction's mode
  val dma_send        = RegInit(false.B) //sending DMA requests to A channel on progress
  val dma_resp        = RegInit(false.B) //receiveving  DMA responces from  D channel on progress
  val dma_counter_a   = RegInit(0.U(log2Ceil(math.max(max_x_regs, params.Cout) + 1).W))  
  val dma_counter_d   = RegInit(0.U(log2Ceil(math.max(max_x_regs, params.Cout) + 1).W)) 
  
  //Select and Accumulte control Signals 
  val lock            = RegInit(false.B) //send one DMA request to A channel and wait the responce from D channel (muitex)  
  val READ_ON         = RegInit(false.B)
  
  // Matrices Addresses
  val adr_X      =  RegInit(0.U(64.W)) 
  val adr_W      =  RegInit(0.U(64.W)) 
  val adr_O      =  RegInit(0.U(64.W)) 
  
  //Register to save dimension values 
  val dma_limit             = RegInit(0.U(log2Ceil(params.Cin + 1).W)) //Cin/X_slice
  val cout_reg              = RegInit(params.Cout.U(log2Ceil(params.Cout + 1).W))
  val cin_reg               = RegInit(params.Cout.U(log2Ceil(params.Cin + 1).W))
  val rin_reg               = RegInit(params.Rin.U(log2Ceil(params.Rin + 1).W))
  val x_slice_Reg           = RegInit(params.x_slice.U(log2Ceil(params.x_slice + 1).W))
  val y_slice_Reg           = RegInit(params.y_slice.U(log2Ceil(params.y_slice + 1).W))
  val x_slice_weights_reg   = RegInit(max_w_elems.U(log2Ceil(max_w_elems + 1).W)) // to bring all corresping weights for all x_elemnts  
  val x_slice_input_reg     = RegInit(max_x_regs.U(log2Ceil(max_x_regs + 1).W)) // so in worst case every sync Mem have hiw own X_reg 


  // if(params.SCALE){ //SCALE
    val scale = RegInit(0.U(32.W)) // 32-bit register for IEEE 754 float
  // }  

  //bitwidths 
  val input_bits  = RegInit(0.U(6.W)) //  input bits 
  val weight_bits = RegInit(0.U(6.W)) //  weights bits 
  val output_bits = RegInit(0.U(6.W)) //  output bits 

  // if(params.DEBUG){
    //Performace counters per state
    val PC_loadX    =  RegInit(0.U(64.W)) 
    val PC_Generate =  RegInit(0.U(64.W)) 
    val PC_loadW    =  RegInit(0.U(64.W)) 
    val PC_Select   =  RegInit(0.U(64.W)) 
    val PC_storeO   =  RegInit(0.U(64.W)) 
    val PC_loadW_and_Select = RegInit(0.U(64.W)) 
  // }

  //Dynamic Input Paramters  characteristcs for every w element 
  val all_available_elems   = RegInit(0.U(log2Ceil(params.Cin + 1).W))                        //new 
  val elemOffVec            = Reg(Vec(totalSyncMems, UInt(log2Ceil(maxParts).W)))             // Keep in what offset ot row is located the element weight want to read 
  val w_reg_valid           = Reg(Vec(totalSyncMems, Bool()))                                 // true -> selected value from BRAM is valid   
  val dirty_elems_x         = RegInit(0.U(log2Ceil(params.XBitWidth/params.minInputBits).W))  //new 
  val all_available_elems_x = RegInit(0.U(log2Ceil(params.Cout + 1).W))                       //new 
  val w_elems_per_reg       = RegInit((params.WBitWidth / params.minWeightBits).U)            //How many weight elements fit in one Weight register 
  val x_elems_per_reg       = RegInit((params.XBitWidth / params.minInputBits).U)             //How many input elements fit  in one input register 

  //Dynamic Bitwidth 
  val mask_in                 =  RegInit(0.U(log2Ceil(((1 << params.XBitWidth ) - 1 )  + 1).W))
  val mask_w                  =  RegInit(0.U(log2Ceil(((1 << params.WBitWidth ) - 1 )  + 1).W))  
  val mask_p                  =  RegInit(0.U(log2Ceil(((1 << (params.WBitWidth +  params.XBitWidth) ) - 1 )  + 1).W))   
  val block_rows_1              =  RegInit(0.U(log2Ceil((((1 << (params.WBitWidth  -2 ))) )  + 1).W))
  val block_rows_2              =  RegInit(0.U(log2Ceil((((1 << (params.WBitWidth  -2 ))) )  + 1).W))
  val blocks_in_Sync_mem_1      =  RegInit(0.U(log2Ceil((((1 << (params.WBitWidth - params.minWeightBits ))) )  + 1).W))
  val blocks_in_Sync_mem_2      =  RegInit(0.U(log2Ceil((((1 << (params.WBitWidth - params.minWeightBits ))) )  + 1).W))

  val chunks_per_Product_bits =  RegInit(0.U(log2Ceil((((params.WBitWidth +  params.XBitWidth) ))  + 1).W))   

  //indexing extra registers 
  val mul1 = RegInit(0.U(16.W))
  val mul2 = RegInit(0.U(16.W))
  // A channel 
  val elements_to_read = RegInit(0.U((log2Ceil(max_w_elems) + 1).W))
  val chunk_addres     = RegInit(0.U(64.W))
  //D Channel 
  val elements_to_read_temp = RegInit(0.U((log2Ceil(max_w_elems) + 1).W))  
  val bytes_to_read         = RegInit(0.U(4.W))
  val reg_idx_start         = RegInit(0.U((log2Ceil(max_w_elems) + 1).W))  
  val offset_in_chunk_1     = RegInit(0.U(3.W))
  val offset_in_chunk_2     = RegInit(0.U(3.W))


  val step_1 = params.step_1 
  val totalGroups_1= totalSyncMems / step_1
  val stepCycle_1 = RegInit(0.U((log2Ceil(totalGroups_1) + 1).W))

  val step_2 = params.step_2  //TODO  make it work
  val totalGroups_2= totalSyncMems / step_2
  val stepCycle_2 = RegInit(0.U((log2Ceil(totalGroups_2) + 1).W))

  val maxCount = totalSyncMems / step_2  
  val product_counter = RegInit(0.U(log2Ceil(maxCount + 1).W))


  // ChunkSignExtender Module 
  val chunk_nums = maxParts + 2
  val max_ch =  scala.math.max(step_1, step_2) 
  val chunkExtenders = Seq.fill(totalSyncMems,chunk_nums) { Module(new ChunkSignExtender(params.XBitWidth))}
  for {
    i <- 0 until totalSyncMems
    j <- 0 until chunk_nums
  } {
    val ext = chunkExtenders(i)(j)
        ext.io.data       := 0.U
        ext.io.input_bits := 0.U
        ext.io.mask       := 0.U
        ext.io.idx        := 0.U
  }

  
  // DMA bus parameters ( how many register or elements fitr in 64 bits dma channel)
   val elemsPerChunk_in = RegInit(0.U(5.W))  // holds up to 16  
   val RegsPerChunk_in  = RegInit((64 / params.XBitWidth).U(math.max(1, log2Ceil(64 / params.XBitWidth) + 1).W)) 
   val elemsPerChunk_w  = RegInit(0.U(5.W))  // holds up to 16  
   val RegsPerChunk_w   = RegInit((64 / params.WBitWidth).U(math.max(1, log2Ceil(64 / params.WBitWidth) + 1).W))

  //A Chunk Offset Module 
  val chunkInfoModule_A = Module(new ChunkInfoModule_A(params,max_w_elems))
  //inputs 
  chunkInfoModule_A.io.cin_reg          := cin_reg
  chunkInfoModule_A.io.j_x              := 0.U
  chunkInfoModule_A.io.x_elems_per_reg  := x_elems_per_reg
  chunkInfoModule_A.io.elemsPerChunk_in := elemsPerChunk_in
  chunkInfoModule_A.io.adr_X            := adr_X
  chunkInfoModule_A.io.RegsPerChunk_in  := RegsPerChunk_in
  chunkInfoModule_A.io.mul1             := mul1
  chunkInfoModule_A.io.mul2             := mul2

  //D Chunk Offset Module 
  val chunkInfoModule_D = Module(new ChunkInfoModule_D(params,max_w_elems,max_x_regs))
  //inputs 
  chunkInfoModule_D.io.cin_reg          := cin_reg
  chunkInfoModule_D.io.j_x_temp         := 0.U
  chunkInfoModule_D.io.x_elems_per_reg  := x_elems_per_reg
  chunkInfoModule_D.io.elemsPerChunk_in := elemsPerChunk_in
  chunkInfoModule_D.io.RegsPerChunk_in  := RegsPerChunk_in
  chunkInfoModule_D.io.dma_counter_d    := 0.U
  chunkInfoModule_D.io.mul1             := mul1
  chunkInfoModule_D.io.mul2             := mul2


  // Elaboration time parameters to avoid div(/) and mod(%)
  val x_slice: Int = params.x_slice  // must be power of 2, e.g. 16
  val x_slice_mask = (x_slice - 1).U
  val x_slice_log2 = log2Ceil(x_slice)
  val max_val = 16 * x_slice
  val max_mask = (max_val - 1).U


  // Define states for the FSM
  val sIdle :: sLoadX :: sGenerateRegFiles :: sLoadW_and_sSelectAndAccumulate :: sStoreOutput :: sDELAY :: Nil = Enum(6)
  val state = RegInit(sIdle)

  //If cmd.ready is hardcoded to true.B, the CPU ignores io.busy  SOS 
  io.busy     := (state =/= sIdle) 
  cmd.ready   := (state === sIdle)
  
   switch(state) {
    is(sIdle) {
      when(cmd.fire && (mode_0)) {        
        adr_X         := rs1
        x_slice_Reg   := rs2

        //DMA init 
        dma_send      := true.B
        dma_resp      := true.B
        dma_counter_a := 0.U 
        dma_counter_d := 0.U 

        //indexer init 
        i_x       := 0.U 
        j_x       := 0.U 
        i_x_start := 0.U 
        j_x_start := 0.U 
        loops_cnt := 0.U 
        i_o       := 0.U 
        j_o       := 0.U 
        i_w_temp  := 0.U 
        j_x_temp  := 0.U 
        
        // XS YS Registers Init 
        val mux = Mux(rin_reg >= y_slice_Reg,y_slice_Reg,rin_reg)
        YS      := mux
        YS_b    := mux
        elemsPerChunk_in :=  Mux(input_bits === 8.U , 8.U , 16.U)  
        elemsPerChunk_w  :=  Mux(weight_bits === 8.U , 8.U , 16.U)  

        X_reg := VecInit(Seq.fill(params.y_slice)(VecInit(Seq.fill(max_x_regs)(0.S(params.XBitWidth.W)))))
      } 

      when(cmd.fire && (mode_1)) {
        adr_W     := rs1
        // state     := sLoadX   

        val scaledSlice        = rs2(15, 0)   // 16 bits
        x_slice_weights_reg   := rs2(31, 16)  // 16 bits
        dma_limit             := rs2(47, 32)  // 16 bits

        val clamped        = Mux(cin_reg >= scaledSlice, scaledSlice, cin_reg)
        val elems_per_word = Mux(input_bits === 4.U, params.XBitWidth.U >> 2, params.XBitWidth.U >> 3)
        val temp_mul       = clamped * elems_per_word

        x_slice_input_reg := scaledSlice
        XS                := clamped
        XS_b              := clamped

        x_elems_per_reg := elems_per_word // params.XBitWidth.U/input_bits 
        w_elems_per_reg := Mux(weight_bits === 4.U, params.WBitWidth.U >> 2, params.WBitWidth.U >> 3) //params.WBitWidth.U/weight_bits 

        //before load X
        all_available_elems_x := (temp_mul).min(cin_reg)  //( clamped * (params.XBitWidth.U/input_bits )).min(cin_reg - j_x) 
        mul1                  := 0.U
        mul2                  := temp_mul

        //dynamic bitwitdh parameters 
        val p_bits = input_bits + weight_bits
        mask_in                 := (1.U << input_bits) - 1.U
        chunks_per_Product_bits := p_bits
        mask_p                  := (1.U << p_bits) - 1.U
        mask_w                  := (1.U << weight_bits) - 1.U 

        val block_rows              = (1.U << (weight_bits  -2.U )) 
        block_rows_1              :=   block_rows
        block_rows_2              :=   block_rows


        val blocks_in_Sync_mem      = 1.U << (params.WBitWidth.U - weight_bits ) 
        blocks_in_Sync_mem_1 := blocks_in_Sync_mem
        blocks_in_Sync_mem_2 := blocks_in_Sync_mem

        
        //input
        chunkInfoModule_A.io.x_elems_per_reg := elems_per_word
        chunkInfoModule_A.io.mul1 := 0.U 
        chunkInfoModule_A.io.mul2 := temp_mul   

        //output 
        elements_to_read := chunkInfoModule_A.io.elements_to_read 
        chunk_addres     := chunkInfoModule_A.io.chunk_address
         
        
        //input
        chunkInfoModule_D.io.x_elems_per_reg  := elems_per_word
        chunkInfoModule_D.io.elemsPerChunk_in := elemsPerChunk_in
        chunkInfoModule_D.io.RegsPerChunk_in  := RegsPerChunk_in
        chunkInfoModule_D.io.mul1             := 0.U
        chunkInfoModule_D.io.mul2             := temp_mul

        //output 
        bytes_to_read         :=  chunkInfoModule_D.io.bytes_to_read 
        reg_idx_start         :=  chunkInfoModule_D.io.reg_idx_start
        offset_in_chunk_1     :=  chunkInfoModule_D.io.offset_in_chunk_1
        elements_to_read_temp := chunkInfoModule_D.io.elements_to_read_temp

      }

      when(cmd.fire && (mode_2)) {
        adr_O    := rs1
        cout_reg := rs2  
      }

      when(cmd.fire && (mode_3)) {
        y_slice_Reg := rs2 
        cin_reg := rs1 
      } 
      
      when(cmd.fire && (mode_5)) {
        LOOPS   := rs1 
        rin_reg := rs2
      }
       
     if(params.SCALE) { //SCALE  
      when(cmd.fire && (mode_7)) {
        scale   := rs1
      }
     }

      when(cmd.fire && (mode_8)) {
        input_bits   := rs1(5,0)
        weight_bits  := rs1(11,6)
        output_bits  := rs1(17,12)

      if(params.DEBUG){
        PC_loadX    := 0.U 
        PC_Generate := 0.U 
        PC_loadW    := 0.U 
        PC_Select   := 0.U 
        PC_storeO   := 0.U 
      }

      } 

      when(cmd.fire && mode_10) { 
        state := sLoadX
      }

    }
  is(sLoadX) {
  if(params.DEBUG){  
    PC_loadX := PC_loadX + 1.U 
  }
  

  when(dma_send && !dma.io.busy ) { //send request to DMA in A Channel  
    
    val j_x_next = j_x + elements_to_read 
    
    dma.io.mode   := false.B  
    dma.io.addr   := chunk_addres
    dma_counter_a := dma_counter_a + elements_to_read            
    dma.io.valid  := true.B
    dma_send      := dma_counter_a < all_available_elems_x  - elements_to_read
    j_x           := j_x_next 


    chunkInfoModule_A.io.j_x := j_x_next
    elements_to_read := chunkInfoModule_A.io.elements_to_read 
    chunk_addres     := chunkInfoModule_A.io.chunk_address

  }

  when(dma.io.d_valid) { //response fron DMA in D channel 

    val j_x_temp_next      = j_x_temp + elements_to_read_temp
    val dma_counter_d_next = dma_counter_d + elements_to_read_temp

    val data  = dma.io.readData                                                                                                         // UInt(64.W)
    val bytes = VecInit(Seq.tabulate(64 / params.XBitWidth)(i => data((i + 1) *  params.XBitWidth - 1, i *  params.XBitWidth).asSInt))

    for (i <- 0 until 64 / params.XBitWidth) {
      when(i.U < bytes_to_read) { 
        X_reg(Rin_cnt)(reg_idx_start + i.U) := bytes(offset_in_chunk_1 + i.U)
      }
    }

    dma_counter_d := dma_counter_d_next
    dma_resp      := dma_counter_d < all_available_elems_x - elements_to_read_temp
    j_x_temp      := j_x_temp_next


    //input 
    chunkInfoModule_D.io.j_x_temp      := j_x_temp_next
    chunkInfoModule_D.io.dma_counter_d := dma_counter_d_next

    //output 
    bytes_to_read         := chunkInfoModule_D.io.bytes_to_read
    reg_idx_start         := chunkInfoModule_D.io.reg_idx_start
    offset_in_chunk_1     := chunkInfoModule_D.io.offset_in_chunk_1
    elements_to_read_temp := chunkInfoModule_D.io.elements_to_read_temp
  }

  when(!dma_resp && !dma_send ) { 
      dma_send      := true.B && (Rin_cnt < YS -1.U)
      dma_resp      := true.B && (Rin_cnt < YS -1.U)   
      dma_counter_a := 0.U 
      dma_counter_d := 0.U 
      Rin_cnt       := Rin_cnt + 1.U 
      j_x           := Mux(Rin_cnt < YS -1.U,j_x_start,j_x)
      i_x           := Mux(Rin_cnt < YS -1.U,i_x + 1.U,i_x)
      mul1          := Mux(Rin_cnt < YS -1.U,cin_reg*(i_x + 1.U),mul1)

      //before load X 
      val XS_temp   = Mux(cin_reg - j_x_start  >= x_slice_input_reg,x_slice_input_reg,cin_reg - j_x_start )
      val mul1_temp = (i_x + 1.U) * cin_reg
      val mul2_temp = XS_temp * x_elems_per_reg

      XS            := XS_temp
      mul2          := mul2_temp
      mul1          := mul1_temp

      //before load X
      val bit_offset_in_byte = ((mul1_temp + j_x_start) * input_bits) & (params.XBitWidth.U - 1.U) //( ((i_x * cin_reg) + j_x) * input_bits) %  params.XBitWidth.U
      val skipInFirstByte = Mux(input_bits === 4.U, bit_offset_in_byte >> 2, bit_offset_in_byte >> 3) //bit_offset_in_byte / input_bits 
      dirty_elems_x          := skipInFirstByte

      //++
      val elems_per_word    = Mux(input_bits === 4.U, params.XBitWidth.U >> 2, params.XBitWidth.U >> 3)
      all_available_elems_x := (XS * elems_per_word).min(cin_reg - j_x_start)  //( XS * (params.XBitWidth.U/input_bits )).min(cin_reg - j_x) 
      j_x_temp              := j_x_start

      chunkInfoModule_A.io.j_x  := j_x_start
      chunkInfoModule_A.io.mul1 := mul1_temp
      chunkInfoModule_A.io.mul2 := mul2_temp
      elements_to_read          := chunkInfoModule_A.io.elements_to_read
      chunk_addres              := chunkInfoModule_A.io.chunk_address

      //input
      chunkInfoModule_D.io.j_x_temp         := j_x_start
      chunkInfoModule_D.io.mul1             := mul1_temp
      chunkInfoModule_D.io.mul2             := mul2_temp

      //output 
      bytes_to_read         :=  chunkInfoModule_D.io.bytes_to_read 
      reg_idx_start         :=  chunkInfoModule_D.io.reg_idx_start
      offset_in_chunk_1     :=  chunkInfoModule_D.io.offset_in_chunk_1
      elements_to_read_temp := chunkInfoModule_D.io.elements_to_read_temp


  }

  when(Rin_cnt === YS){  
      val x_slice_reg_elems = x_slice_input_reg * x_elems_per_reg
      load_x_cnt := load_x_cnt + 1.U
      // state      := sGenerateRegFiles
      j_x_start  := Mux(j_x_start + x_slice_reg_elems   >= cin_reg , 0.U,j_x_start + x_slice_reg_elems )
      i_x_start  := Mux(j_x_start + x_slice_reg_elems   >= cin_reg , i_x_start + YS -0.U,i_x_start)
      cycleCount_1 := 0.U
      Products.foreach(_ := 0.U)
      stepCycle_1     := 0.U 


      ////////////////////////////////////////////////////////////////////////////////////
      val remain_in_column      = cin_reg - i_w
      val remain_in_column_regs = Mux(w_elems_per_reg === 1.U,remain_in_column,(remain_in_column + 1.U) >> 1)                  // (remain_in_column + w_elems_per_reg -1.U)/w_elems_per_reg 
      val XS_W_temp             = Mux(remain_in_column_regs >= x_slice_weights_reg,x_slice_weights_reg,remain_in_column_regs)  //max_w_elems
      XS_W  := XS_W_temp
      W_reg := VecInit(Seq.fill(params.num_filters)(VecInit(Seq.fill(max_w_elems)(VecInit(Seq.fill(buffers)(0.S(params.WBitWidth.W)))))))  //new 

      dirty_elems_w.foreach(_ := 0.U)

      // load_w_buff_idx := 0.U 
      // select_buff_idx := 0.U 

      //before load W
      val temp_mul1 = j_w * cin_reg 
      val temp_mul2  = XS_W_temp * w_elems_per_reg 
      mul1 := temp_mul1 
      mul2 := temp_mul2
      val bit_offset_in_byte = (((temp_mul1)) * weight_bits) & (params.WBitWidth.U - 1.U)
      val skipInFirstByte    = bit_offset_in_byte / weight_bits
      dirty_elems_w(0)    := skipInFirstByte
      all_available_elems := ( temp_mul2).min(cin_reg - i_w)

        //input 
      chunkInfoModule_A.io.j_x              := i_w
      chunkInfoModule_A.io.x_elems_per_reg  := w_elems_per_reg
      chunkInfoModule_A.io.elemsPerChunk_in := elemsPerChunk_w
      chunkInfoModule_A.io.adr_X            := adr_W
      chunkInfoModule_A.io.RegsPerChunk_in  := RegsPerChunk_w
      chunkInfoModule_A.io.mul1             := temp_mul1
      chunkInfoModule_A.io.mul2             := temp_mul2

      //output 
      elements_to_read := chunkInfoModule_A.io.elements_to_read
      chunk_addres     := chunkInfoModule_A.io.chunk_address

        //input 
      chunkInfoModule_D.io.j_x_temp         := i_w
      chunkInfoModule_D.io.x_elems_per_reg  := w_elems_per_reg
      chunkInfoModule_D.io.elemsPerChunk_in := elemsPerChunk_w
      chunkInfoModule_D.io.RegsPerChunk_in  := RegsPerChunk_w
      chunkInfoModule_D.io.mul1             := temp_mul1
      chunkInfoModule_D.io.mul2             := temp_mul2

      //output 
      bytes_to_read         := chunkInfoModule_D.io.bytes_to_read
      reg_idx_start         := chunkInfoModule_D.io.reg_idx_start
      offset_in_chunk_2     := chunkInfoModule_D.io.offset_in_chunk_1
      elements_to_read_temp := chunkInfoModule_D.io.elements_to_read_temp

      dma_send      := true.B
      dma_resp      := true.B
      dma_counter_a := 0.U
      dma_counter_d := 0.U
      w_count       := 0.U 
      i_w_temp      := i_w

      if(params.SimpleCache4x8) {  
        state := Mux(input_bits === 4.U && weight_bits === 8.U, sLoadW_and_sSelectAndAccumulate, sGenerateRegFiles )
      } else { 
      state      := sGenerateRegFiles
      }

 

    ////////////////////////////////////////////////////////////////////////////////////////////////////  

  }

}
    
is(sGenerateRegFiles) {
      if(params.DEBUG){  
        PC_Generate := PC_Generate + 1.U
      }
      
if( step_1 == totalSyncMems ) { 
      for (sync_mem_idx <- 0 until totalSyncMems) { 
      
        // mapping to 2D space 
        val shiftAmt   = Mux(block_rows_1 === 4.U, 2.U, 6.U)                                                           // 4 = 2^2, 64 = 2^6
        val start_row  = counter_1 << shiftAmt
         
        val x_th_x_reg = Mux(blocks_in_Sync_mem_1 === 1.U, (sync_mem_idx.U & x_slice_mask) + counter_1, ((sync_mem_idx.U << 4) + counter_1) & max_mask)
        val y_th_xreg = Mux(weight_bits === 8.U, sync_mem_idx.U >> x_slice_log2,((sync_mem_idx.U << 4) + counter_1) >> log2Ceil(max_val))

        when(cycleCount_1 =/= 0.U ) { 
          val finalAddressInBRAM =  start_row + (cycleCount_1 -1.U)   
          temp_muls_mem(sync_mem_idx).write(finalAddressInBRAM, Products(sync_mem_idx)) 
        }
        
        val data      =   X_reg(y_th_xreg)(x_th_x_reg).asUInt  // width = XBITWIDTH.W
        val P_data    =   Products(sync_mem_idx) 
        val P_slices  =   Wire(Vec(maxParts, UInt((product_bitwidth).W)))
          
        //split 
        for (i <- 0 until maxParts) {

          val extender = chunkExtenders(sync_mem_idx)(i)
          extender.io.data       := data
          extender.io.input_bits := input_bits
          extender.io.mask       := mask_in     
          extender.io.idx        := i.U
          val signedChunk = extender.io.out

          val absVal    = signedChunk.abs().asUInt
          val chunk_p   = (P_data >> (i.U * chunks_per_Product_bits)) & mask_p  // UInt(input_bits.W)
          val scaled    =  (absVal << 1) 
          P_slices(i)   := Mux(i.U < x_elems_per_reg , chunk_p + scaled,chunk_p)

        }

          val packed = Wire(UInt(product_bitwidth.W))
          var acc: UInt = 0.U

        //Concat and Accumulate 
        for (i <- 0 until maxParts) {
          val shiftAmt = i.U * chunks_per_Product_bits
          val shifted  = P_slices(i) << shiftAmt
          acc = acc | shifted
        }

        packed := acc
        Products(sync_mem_idx) := packed 
      }   

      cycleCount_1 := cycleCount_1 + 1.U      

} else {  

    for (i <- 0 until step_1) {
        val sync_mem_idx = stepCycle_1 * step_1.U + i.U
        val shiftAmt   = Mux(block_rows_1 === 4.U, 2.U, 6.U)
        val start_row  = counter_1 << shiftAmt
        val finalAddressInBRAM = start_row + (cycleCount_1 - 1.U)

        val x_th_x_reg = Mux(
          blocks_in_Sync_mem_1 === 1.U,
          (sync_mem_idx & x_slice_mask) + counter_1,
          ((sync_mem_idx << 4) + counter_1) & max_mask
        )

        val y_th_xreg = Mux(
          weight_bits === 8.U,
          sync_mem_idx >> x_slice_log2,
          ((sync_mem_idx << 4) + counter_1) >> log2Ceil(max_val)
        )

        // ---------------- WRITE (Must be static indexing) ------------------
        for (j <- 0 until totalSyncMems) {
          when(sync_mem_idx === j.U && cycleCount_1 =/= 0.U ) { //&& cycleCount_1 =/= 0.U
            temp_muls_mem(j).write(finalAddressInBRAM, Products(j))
          }
        }

        // ---------------- DATA LOAD + PROCESS ------------------
        val data   = X_reg(y_th_xreg)(x_th_x_reg).asUInt
        val P_data = Products(sync_mem_idx)
        val P_slices = Wire(Vec(maxParts, UInt(product_bitwidth.W)))

        for (k <- 0 until maxParts) {
          val extender = chunkExtenders(i)(k) //use les ectenders now 
          extender.io.data       := data
          extender.io.input_bits := input_bits
          extender.io.mask       := mask_in
          extender.io.idx        := k.U

          val signedChunk = extender.io.out
          val absVal      = signedChunk.abs().asUInt
          val chunk_p     = (P_data >> (k.U * chunks_per_Product_bits)) & mask_p
          val scaled      = absVal << 1
          P_slices(k)     := Mux(k.U < x_elems_per_reg, chunk_p + scaled, chunk_p)
        }

        val packed = Wire(UInt(product_bitwidth.W))
        var acc: UInt = 0.U
        for (k <- 0 until maxParts) {
          val shiftAmt = k.U * chunks_per_Product_bits
          acc = acc | (P_slices(k) << shiftAmt)
        }

        packed := acc
        Products(sync_mem_idx) := packed
    }


    when (stepCycle_1 === (totalGroups_1- 1).U ) {
      stepCycle_1 := 0.U
      cycleCount_1 := cycleCount_1 + 1.U
    } .otherwise {
      stepCycle_1 := stepCycle_1 + 1.U
    }

}
    when(cycleCount_1 === (block_rows_1 -0.U) && stepCycle_1 === (totalGroups_1- 1).U  ) {
        counter_1    := counter_1 + 1.U
        cycleCount_1 := 0.U
        Products.foreach(_ := 0.U)
    } 
    
    when(counter_1 === blocks_in_Sync_mem_1 - 1.U && cycleCount_1 === (block_rows_1 ) && stepCycle_1 === (totalGroups_1- 1).U) { //4bits => 7 cycles delay  
        Rin_cnt       := 0.U
        j_x           := j_x_start
        i_x           := i_x_start
        cycleCount_1  := 0.U
        counter_1     := 0.U

        READ_ON       := true.B
        delay         := true.B
        delay_counter := 0.U
        stepCycle_2 := 0.U 

        state            := sLoadW_and_sSelectAndAccumulate
    }       
       
    }
is(sLoadW_and_sSelectAndAccumulate) {

  if(params.DEBUG){  
    PC_loadW_and_Select := PC_loadW_and_Select + 1.U 
  }  

  
  when(buffers_mode.reduce(_ || _)) { // Select and accumualte Phase 

  val buff_index = select_buff_idx //Mux(buffers(0), 0.U, 1.U)

  if(params.DEBUG){  
      PC_Select := PC_Select + 1.U 
  } 

  
   when(input_bits === 4.U && weight_bits === 8.U && !Done) { 
    val y = 0 
     if(params.SimpleCache4x8){ 
 
      for (elem <- 0 until totalSyncMems ) {  //params.step_3
        val emem_idx = start_base + elem.U

        val w_sint = W_reg(0)(emem_idx)(buff_index)
        val w_abs  = w_sint.abs().asUInt() 
        
        val x_reg_idx = emem_idx >> 1           // Same as i / 2
        val x_offset  = emem_idx(0)             // Same as i % 2 → LSB tells if it's 0 or 1

        val extender_1 = chunkExtenders(elem)(maxParts)
        extender_1.io.data       :=  X_reg(y)(x_reg_idx).asUInt // W_reg(0)(W_reg_Index)(buff_index).asUInt
        extender_1.io.input_bits := input_bits 
        extender_1.io.mask       := mask_in 
        extender_1.io.idx        := x_offset 
        val X_Sint_part = extender_1.io.out 

        val abs_x_uint  = X_Sint_part.abs().asUInt

        val sign_w = w_sint(7)   // MSB: 1 means negative, 0 means positive
        val sign_x = X_Sint_part(3)
        val product_sign = sign_x ^ sign_w // 0 => + | 1 => - 

        val mapped_x = (abs_x_uint - 1.U) >> 1 

        val w_reg_valid_temp = w_abs =/= 0.U && abs_x_uint =/= 0.U  

        Products(elem) :=  Cache_4_8(w_abs - 1.U)(mapped_x)  //mapped_x
        elemOffVec(elem) := 0.U  
        w_reg_valid(elem) := w_reg_valid_temp
        DATA_Y(elem) := 0.U   //FIX TRHIS 
        Sign(elem):= product_sign === 0.U  

        val abs_val     =  w_sint.abs()
        val disable     = (abs_x_uint(0) === 0.U) || !w_reg_valid_temp || (abs_x_uint === 0.U)
        val signed_val  = Mux(product_sign === 1.U, -abs_val, abs_val)
        sum(elem) := Mux(disable, 0.S, signed_val)

      }    
      
      delay := false.B 

      when(start_base + totalSyncMems.U  >= XS ){  //XS * x_elems_per_reg
        start_base := 0.U 
        Done := true.B 
      }.otherwise { 
        start_base :=  start_base + totalSyncMems.U  
      }

     }
   } .otherwise {       

if( step_2 == totalSyncMems ) {  

          for (sync_mem_idx <- 0 until totalSyncMems) {
                        
              ////////////////////////  WEIGHTS //////////////////////////////////
                
              val x_th_x_reg = Mux(blocks_in_Sync_mem_1 === 1.U, (sync_mem_idx.U & x_slice_mask) + counter_2, ((sync_mem_idx.U << 4) + counter_2) & max_mask)
              val y_th_xreg = Mux(weight_bits === 8.U, sync_mem_idx.U >> x_slice_log2,((sync_mem_idx.U << 4) + counter_2) >> log2Ceil(max_val))
                
              val base = x_th_x_reg
              val w_idx = Mux(x_elems_per_reg === 1.U, base + cycleCount_2, (base << 1) + cycleCount_2)

              //corresping weight handling 
              val w_id_in_reg = w_idx + dirty_elems_w(buff_index)                      // if we have some dirty elements in  W_reg vector skip them 
              val linear_w    = w_id_in_reg
              val W_reg_Index = Mux(w_elems_per_reg === 1.U, linear_w, linear_w >> 1)  //linear_w / w_elems_per_reg
              val w_offset    = Mux(w_elems_per_reg === 1.U, 0.U, linear_w(0))         //linear_w % w_elems_per_reg 

              //corresping weight register  take elem from register //WHY dotn take 0 1 weigths for select 0 1 hmm because is in differnt rows probably 
              val extender_1 = chunkExtenders(sync_mem_idx)(maxParts)
              extender_1.io.data       := W_reg(0)(W_reg_Index)(buff_index).asUInt
              extender_1.io.input_bits := weight_bits
              extender_1.io.mask       := mask_w
              extender_1.io.idx        := w_offset
              val weight_Sint_part = extender_1.io.out

              val abs_weight_uint  = weight_Sint_part.abs().asUInt

              //Find row  to read  ->  start_row    = (counter) * block_rows_2  //wherse start in currect SyncMem  so the start of Block i need in this Sync Mem 
              val shiftAmt     = Mux(block_rows_2 === 4.U, 2.U, 6.U)                                                            // 4 = 2^2, 64 = 2^6
              val start_row    = counter_2 << shiftAmt
              val row_in_block = Mux(abs_weight_uint(0) === 0.U, (abs_weight_uint >> 1) -1.U , (abs_weight_uint - 1.U) >> 1)
              val row_idx      = start_row + row_in_block                                                                     //(start_row -0.U) +  row_in_block

              //Find offset 
              val elemOffset = cycleCount_2

              /////////////////////////// Activations ///////////////////////////////// 

              val i_th             = row_idx
              val w_reg_valid_temp = w_idx < buff_elems(buff_index) && abs_weight_uint =/= 0.U

              val extender = chunkExtenders(sync_mem_idx)(maxParts +  1)
              extender.io.data       := X_reg(y_th_xreg)(x_th_x_reg).asUInt
              extender.io.input_bits := input_bits
              extender.io.mask       := mask_in   
              extender.io.idx        := elemOffset
              val sign_X_reg_part = extender.io.out

              val sign_x       = sign_X_reg_part(input_bits - 1.U)
              val sign_w       = weight_Sint_part(weight_Sint_part.getWidth - 1)
              val product_sign = sign_x ^ sign_w // 0 => + | 1 => - 

              //////////////////////// BRAMs //////////////////////////////////

              DATA_Y(sync_mem_idx) := RegNext(y_th_xreg)  //the bRAM  you read what Y value has NOT SURE ABOU y_th_reg here 

              val abs_val     = sign_X_reg_part.abs()
              val disable     = (abs_weight_uint(0) === 0.U) || !w_reg_valid_temp || (abs_weight_uint === 0.U)
              val signed_val  = Mux(product_sign === 1.U, -abs_val, abs_val)
              sum(sync_mem_idx) := RegNext(Mux(disable, 0.S, signed_val))


              val enable_read = READ_ON && w_reg_valid_temp 
              val finalAddressInBRAM =  i_th 

              Products(sync_mem_idx) := temp_muls_mem(sync_mem_idx).read(finalAddressInBRAM,enable_read)  
              Sign(sync_mem_idx)     := RegNext(product_sign === 0.U) // + True | - False 

              elemOffVec(sync_mem_idx)  := RegNext(elemOffset)
              w_reg_valid(sync_mem_idx) := RegNext(w_reg_valid_temp)
          }
          
          when (delay_counter === 1.U ){ 
            delay := false.B 
          }.otherwise{
            delay_counter := delay_counter + 1.U 
          } 

          when(READ_ON && !Done ) {  //Read values 
            cycleCount_2 := Mux(cycleCount_2 === x_elems_per_reg - 1.U , 0.U ,cycleCount_2 + 1.U) 
            counter_2    := Mux(cycleCount_2 === x_elems_per_reg - 1.U ,counter_2 + 1.U,counter_2)
            Done       := Done || (cycleCount_2 === x_elems_per_reg - 1.U  && counter_2 === blocks_in_Sync_mem_2 - 1.U)
          }

} else {  
     
       for (i <- 0 until step_2) {
            val sync_mem_idx =  stepCycle_2 *(step_2.U) + i.U

            ////////////////////////  WEIGHTS //////////////////////////////////

            val x_th_x_reg = Mux(
              blocks_in_Sync_mem_1 === 1.U,
              (sync_mem_idx & x_slice_mask) + counter_2,
              ((sync_mem_idx << 4) + counter_2) & max_mask
            )

            val y_th_xreg = Mux(
              weight_bits === 8.U,
              sync_mem_idx >> x_slice_log2,
              ((sync_mem_idx << 4) + counter_2) >> log2Ceil(max_val)
            )

            val base  = x_th_x_reg
            val w_idx = Mux(x_elems_per_reg === 1.U, base + cycleCount_2, (base << 1) + cycleCount_2)

            val w_id_in_reg = w_idx + dirty_elems_w(buff_index)
            val linear_w    = w_id_in_reg
            val W_reg_Index = Mux(w_elems_per_reg === 1.U, linear_w, linear_w >> 1)
            val w_offset    = Mux(w_elems_per_reg === 1.U, 0.U, linear_w(0))

            val extender_1 = chunkExtenders(i)(maxParts)
            extender_1.io.data       := W_reg(0)(W_reg_Index)(buff_index).asUInt
            extender_1.io.input_bits := weight_bits
            extender_1.io.mask       := mask_w
            extender_1.io.idx        := w_offset
            val weight_Sint_part = extender_1.io.out

            val abs_weight_uint  = weight_Sint_part.abs().asUInt

            val shiftAmt     = Mux(block_rows_2 === 4.U, 2.U, 6.U)
            val start_row    = counter_2 << shiftAmt
            val row_in_block = Mux(abs_weight_uint(0) === 0.U, (abs_weight_uint >> 1) - 1.U, (abs_weight_uint - 1.U) >> 1)
            val row_idx      = start_row + row_in_block

            val elemOffset = cycleCount_2

            /////////////////////////// Activations ///////////////////////////////// 

            val i_th             = row_idx
            val w_reg_valid_temp = w_idx < buff_elems(buff_index) && abs_weight_uint =/= 0.U

            val extender = chunkExtenders(i)(maxParts + 1)
            extender.io.data       := X_reg(y_th_xreg)(x_th_x_reg).asUInt
            extender.io.input_bits := input_bits
            extender.io.mask       := mask_in
            extender.io.idx        := elemOffset
            val sign_X_reg_part = extender.io.out

            val sign_x       = sign_X_reg_part(input_bits - 1.U)
            val sign_w       = weight_Sint_part(weight_Sint_part.getWidth - 1)
            val product_sign = sign_x ^ sign_w

            //////////////////////// BRAMs //////////////////////////////////

            DATA_Y(sync_mem_idx) := RegNext(y_th_xreg)

            val abs_val     = sign_X_reg_part.abs()
            val disable     = (abs_weight_uint(0) === 0.U) || !w_reg_valid_temp || (abs_weight_uint === 0.U)
            val signed_val  = Mux(product_sign === 1.U, -abs_val, abs_val)
            sum(sync_mem_idx) := RegNext(Mux(disable, 0.S, signed_val))

            val enable_read = READ_ON && w_reg_valid_temp
            val finalAddressInBRAM = i_th

            // // temp_muls_mem must be indexed statically
            // for (j <- 0 until totalSyncMems) {
            //   val enable_read_new = (sync_mem_idx === j.U)  //&& enable_read
            //   // when(sync_mem_idx === j.U && enable_read) {
            //     Products(sync_mem_idx) :=  (sync_mem_idx === j.U) //temp_muls_mem(j).read(finalAddressInBRAM,enable_read_new) 
            //   // }
            // }

            // for (j <- 0 until totalSyncMems) {
            //   val hit = (sync_mem_idx === j.U)
            //   when(hit) {
            //     Products(j) := temp_muls_mem(j).read(finalAddressInBRAM,true.B) 
            //   }
            // }

            when(stepCycle_2 === 0.U ) { 
              Products(sync_mem_idx) := temp_muls_mem(i).read(finalAddressInBRAM,enable_read) 
            }.otherwise { 
              Products(sync_mem_idx) := temp_muls_mem(step_2 + i).read(finalAddressInBRAM,enable_read) 
            }

            Sign(sync_mem_idx) := RegNext(product_sign === 0.U)
            elemOffVec(sync_mem_idx) := RegNext(elemOffset)
            w_reg_valid(sync_mem_idx) := RegNext(w_reg_valid_temp)
          }

          stepCycle_2 := Mux(stepCycle_2 === (totalGroups_2 - 1).U, 0.U, stepCycle_2 + 1.U)


          when (delay_counter === 1.U ) { 
            delay := false.B 
          }.otherwise{
            delay_counter   := delay_counter + 1.U
          } 

          when(READ_ON && !Done  && stepCycle_2  === (totalSyncMems/step_2 - 1).U ) {  //Read values 
            cycleCount_2 := Mux(cycleCount_2 === x_elems_per_reg - 1.U , 0.U ,cycleCount_2 + 1.U)
            counter_2    := 0.U //Mux(cycleCount_2 === x_elems_per_reg - 1.U ,counter_2 + 1.U,counter_2) //            counter_2    := Mux(cycleCount_2 === x_elems_per_reg - 1.U ,counter_2 + 1.U,counter_2)
            Done         := Done || (cycleCount_2 === x_elems_per_reg - 1.U  && counter_2 === blocks_in_Sync_mem_2 - 1.U)
          }
          
 }     
}    

          when(!delay && !Done_acc && stepCycle_2  === 0.U ) { // Accumulate values ( delay for first value only 1 cycle delay ) 
            
            // ACCUMULATOR
            val accum = VecInit((0 until params.y_slice).map { y =>
              (0 until totalSyncMems).map { i => 

                val offset          = elemOffVec(i)
                val w_reg_valid_tmp = w_reg_valid(i)
                val valid_read      = Mux(w_reg_valid_tmp,Products(i),0.U(Products(i).getWidth.W))

                  //kepp from row per block the correct data
                      val readDataVec_part = ( valid_read  >> (offset * chunks_per_Product_bits)) & mask_p  // UInt(input_bits.W)

                      val unsigned_clean = Mux1H(Seq(
                      // (chunks_per_Product_bits ===  6.U)  -> readDataVec_part(5, 0),    //  2+4 = 6 bits
                      // (chunks_per_Product_bits === 10.U)  -> readDataVec_part(9, 0),    //  2+8 = 10 bits
                      (chunks_per_Product_bits ===  8.U)  -> readDataVec_part(7, 0),    //  4+4 = 8 bits
                      (chunks_per_Product_bits === 12.U)  -> readDataVec_part(11, 0),   //  4+8 =12 bits
                      (chunks_per_Product_bits === 16.U)  -> readDataVec_part(15, 0),   //  8+8 =16 bits
                    ))

                    val readDataVec_part_sign = unsigned_clean.zext.asSInt
                    val signedValue = Mux(Sign(i), readDataVec_part_sign - sum(i),  - readDataVec_part_sign - sum(i)) 

                    Mux(DATA_Y(i) === y.U  , signedValue, 0.S(product_bitwidth.W)) 
                  
              }.reduce(_ + _)  // Add all the results for each `i`
              
            })

            // Now update O_reg for each y slice location
            for (y <- 0 until params.y_slice) {
              O_reg(0)(y)(w_idx - 0.U) := O_reg(0)(y)(w_idx - 0.U) + accum(y)
            }

            Done_acc := RegNext(Done) 
        }  

    }
   
  when(Done_acc && w_idx =/= cout_reg) { // select next Phase 
         
          Products.foreach(_ := 0.U) 
          cycleCount_2 := 0.U
          counter_2    := 0.U
          w_idx      := Mux(w_idx === cout_reg,0.U,w_idx +  params.w_slice.U)
          
          //new 
          READ_ON       := true.B
          delay         := true.B
          delay_counter := 0.U

          dirty_elems_w(select_buff_idx) := 0.U
          buff_elems(select_buff_idx)    := 0.U
          Done                           := false.B
          Done_acc                       := false.B
          buffers_mode(select_buff_idx)  := false.B
          select_buff_idx                := select_buff_idx + 1.U
          
    }.elsewhen(w_idx === cout_reg) { 

      when(load_x_cnt >= dma_limit) { 
                i_w        := 0.U
                i_w_start  := 0.U
                load_x_cnt := 0.U
                Rin_cnt    := 0.U
                state      := sStoreOutput
              }.otherwise{
                val XS_temp   = Mux(cin_reg - j_x  >= x_slice_input_reg,x_slice_input_reg,cin_reg - j_x )
                val mul1_temp = i_x * cin_reg
                val mul2_temp = XS_temp * x_elems_per_reg

                i_w           := i_w_start + mul2_temp
                i_w_start     := i_w_start + mul2_temp
                XS            := XS_temp
                X_reg         := VecInit(Seq.fill(params.y_slice)(VecInit(Seq.fill(max_x_regs)(0.S(params.XBitWidth.W)))))
                dma_counter_a := 0.U
                dma_counter_d := 0.U
                mul2          := mul2_temp
                mul1          := mul1_temp

                //before load X
                val bit_offset_in_byte = ((mul1_temp + j_x) * input_bits) & (params.XBitWidth.U - 1.U) //( ((i_x * cin_reg) + j_x) * input_bits) %  params.XBitWidth.U
                val skipInFirstByte = Mux(input_bits === 4.U, bit_offset_in_byte >> 2, bit_offset_in_byte >> 3) //bit_offset_in_byte / input_bits 
                dirty_elems_x          := skipInFirstByte

                //++
                val elems_per_word    = Mux(input_bits === 4.U, params.XBitWidth.U >> 2, params.XBitWidth.U >> 3)
                all_available_elems_x := (XS * elems_per_word).min(cin_reg - j_x)  //( XS * (params.XBitWidth.U/input_bits )).min(cin_reg - j_x) 
                j_x_temp              := j_x

                //new
                // val (elements_to_read_a,chunk_address_a) =  calcChunkInfo_A(cin_reg,j_x,x_elems_per_reg,elemsPerChunk_in,adr_X,RegsPerChunk_in,mul1_temp,mul2_temp)
                // elements_to_read := elements_to_read_a
                // chunk_addres     := chunk_address_a 

                chunkInfoModule_A.io.j_x  := j_x
                chunkInfoModule_A.io.mul1 := mul1_temp
                chunkInfoModule_A.io.mul2 := mul2_temp
                elements_to_read          := chunkInfoModule_A.io.elements_to_read
                chunk_addres              := chunkInfoModule_A.io.chunk_address

                // val (bytes_to_read_d,reg_idx_start_d,offset_in_chunk_1_d,elements_to_read_temp_d) = calcChunkInfo_D(cin_reg,j_x,x_elems_per_reg,elemsPerChunk_in,RegsPerChunk_in,0.U,mul1_temp,mul2_temp)
                // bytes_to_read         :=  bytes_to_read_d 
                // reg_idx_start         :=  reg_idx_start_d
                // offset_in_chunk_1     := offset_in_chunk_1_d
                // elements_to_read_temp := elements_to_read_temp_d 

                //input
                chunkInfoModule_D.io.j_x_temp         := j_x
                chunkInfoModule_D.io.mul1             := mul1_temp
                chunkInfoModule_D.io.mul2             := mul2_temp

                //output 
                bytes_to_read         :=  chunkInfoModule_D.io.bytes_to_read 
                reg_idx_start         :=  chunkInfoModule_D.io.reg_idx_start
                offset_in_chunk_1     :=  chunkInfoModule_D.io.offset_in_chunk_1
                elements_to_read_temp := chunkInfoModule_D.io.elements_to_read_temp

                state := sLoadX


      }
          j_w              := 0.U
          w_idx            := 0.U
          cycleCount_2       := 0.U
          counter_2        := 0.U
          Done             := false.B
          Done_acc         := false.B
          buff_elems.foreach(_ := 0.U)
          // select_buff_idx  := 0.U
          // load_w_buff_idx  := 0.U
          lock             := false.B
         
      }

}

is(sStoreOutput) {
      if(params.DEBUG){  
        PC_storeO := PC_storeO + 1.U
      }

      val remaining_elems = cout_reg - dma_counter_d  // Elements left in the row
      val R_elems_per_chunk = ((elems_per_chunk.U - done_elems_in_block).min(remaining_elems)) 
      val linear_index  = i_o * cout_reg + j_o  
      val chunk_index   = linear_index / ((elems_per_chunk.U)) //.min(remaining_elems))   // Which chunk (64-bit block)
      val chunk_address = adr_O + (chunk_index * 8.U) 

      when(dma_send && !dma.io.busy && !lock) { //send request to DMA in A Channel 
        dma.io.mode := true.B   
      
      //NO Scale    
        val data_chunk = (0 until elems_per_chunk).foldLeft(0.U(64.W)) { (acc, i) =>
            acc | Mux(i.U < R_elems_per_chunk, (O_reg(0)(Rin_cnt)(dma_counter_a + i.U) ).asUInt()  << ((i.U + done_elems_in_block)* params.OutBitWidth.U), 0.U(64.W)) 
        } 
      
       //YES Scale   
      //  val scaleModule = Module(new Scale_Vector) 
      //  val dataVector = VecInit((0 until elems_per_chunk).map(i => Mux(i.U < R_elems_per_chunk, O_reg(0)(Rin_cnt)(dma_counter_a + i.U), 0.S(64.W))))
      //  scaleModule.io.inVector := dataVector 
      //  scaleModule.io.scale    := scale 
    
        // Option 2: Building the mask per byte lane (define beatBytes as total byte lanes in the beat)
        val beatBytes = 8  // Total number of byte lanes in a 64-bit word
        val bytesPerElem = params.OutBitWidth.U >> 3  // Divide by 8
        val startByte = done_elems_in_block * bytesPerElem
        val endByte   = startByte + (R_elems_per_chunk * bytesPerElem) //R_elems_per_chunk
        dma.io.mask := Cat((0 until beatBytes).map { i => (i.U >= startByte) && (i.U < endByte) }.reverse)

        // dma.io.writeData := scaleModule.io.out  // YES SCALE 
           dma.io.writeData :=  data_chunk        // NO Scale  

        dma.io.addr   := chunk_address
        dma.io.valid  := true.B
        dma_counter_a := dma_counter_a + R_elems_per_chunk
        dma_send      := dma_counter_a < cout_reg - R_elems_per_chunk
        dma.io.valid  := true.B

        for (i <- 0 until elems_per_chunk) {
          when(i.U < R_elems_per_chunk) {
              O_reg(0)(Rin_cnt)(dma_counter_a + i.U) := 0.S 
          }
        }

        lock    := true.B 
        j_o := j_o + R_elems_per_chunk 

      }

      when(dma.io.d_valid) { //response fron DMA in D channel   
        dma_counter_d := dma_counter_d + R_elems_per_chunk 
        dma_resp := dma_counter_d < cout_reg - R_elems_per_chunk 
        lock    := false.B 
        done_elems_in_block := Mux(done_elems_in_block === (elems_per_chunk.U - 1.U), 0.U, done_elems_in_block + R_elems_per_chunk)
      }
 
      when(!dma_send && !dma_resp && !(Rin_cnt === YS)) {  
        Rin_cnt       := Rin_cnt + 1.U
        dma_counter_d := 0.U
        dma_counter_a := 0.U
        j_o           := 0.U
        i_o           := i_o + 1.U
        dma_send      := true.B && (Rin_cnt < YS -1.U)
        dma_resp      := true.B && (Rin_cnt < YS -1.U)
      } 

      when(Rin_cnt === YS) {
         when(loops_cnt === LOOPS -1.U){
            Rin_cnt             := 0.U
            state               := sDELAY
            done_elems_in_block := 0.U

         }.otherwise{
            loops_cnt     := loops_cnt + 1.U
            dma_send      := true.B
            dma_resp      := true.B
            dma_counter_a := 0.U
            dma_counter_d := 0.U
            X_reg         := VecInit(Seq.fill(params.y_slice)(VecInit(Seq.fill(max_x_regs)(0.S(params.XBitWidth.W)))))
            Rin_cnt       := 0.U

            //new
            val XS_temp = Mux(cin_reg >= x_slice_input_reg,x_slice_input_reg,cin_reg)
            XS := XS_temp

            //new
            val remain_in_column =  rin_reg - i_x 
            YS :=  Mux(remain_in_column >= y_slice_Reg,y_slice_Reg,remain_in_column)
            
            dma.io.mask := ((1.U << (R_elems_per_chunk * params.OutBitWidth.U)) - 1.U) << (done_elems_in_block * params.OutBitWidth.U) //new
            state := sLoadX

            //before load X
            val bit_offset_in_byte = (((i_x * cin_reg) + j_x) * input_bits) & (params.XBitWidth.U - 1.U) //( ((i_x * cin_reg) + j_x) * input_bits) %  params.XBitWidth.U
            val skipInFirstByte = Mux(input_bits === 4.U, bit_offset_in_byte >> 2, bit_offset_in_byte >> 3) //bit_offset_in_byte / input_bits 
            dirty_elems_x           := skipInFirstByte
            val elems_per_word = Mux(input_bits === 4.U, params.XBitWidth.U >> 2, params.XBitWidth.U >> 3)
            all_available_elems_x := (XS * elems_per_word).min(cin_reg - j_x) //( XS * (params.XBitWidth.U/input_bits )).min(cin_reg - j_x) 
            j_x_temp := j_x 

         }

        }
      }
      is(sDELAY) {
          io.busy     := false.B  
          cmd.ready   := true.B 
        when(cmd.fire && (mode_6)) {
          state := sIdle 
        }

      }


      
          
      
  } 

  val counter_p = RegInit(0.U(5.W)) // Declare outside to preserve value

  if(params.DEBUG) {   
  when(cmd.fire && (mode_9)) {
      
        io.resp.valid := cmd.valid
        io.resp.bits.rd := cmd.bits.inst.rd          
        io.resp.bits.data := MuxLookup(counter_p, 0.U, Array(
            0.U -> PC_loadX,
            1.U -> PC_Generate,
            2.U -> PC_loadW,
            3.U -> PC_Select,
            4.U -> PC_storeO,
            5.U -> PC_loadW_and_Select
        ))

        counter_p := counter_p + 1.U
      } 
}

  when( ( buffers_mode.map(! _).reduce(_ || _)  && w_count =/= cout_reg ) && (state === sLoadW_and_sSelectAndAccumulate || state === sGenerateRegFiles)   ) { // Load W Phase 
      
      val buff_index = load_w_buff_idx 
      if(params.DEBUG){  
        PC_loadW := PC_loadW + 1.U 
      }  
      
      when(dma_send && (!dma.io.busy)) { // send request to DMA in A Channel  
        
        val i_w_next = i_w + elements_to_read 

        dma.io.mode   := false.B  
        dma.io.addr   := chunk_addres 
        dma_counter_a := dma_counter_a + elements_to_read
        dma.io.valid  := true.B
        dma_send      := dma_counter_a < all_available_elems - elements_to_read 
        i_w           := i_w_next 
         
        //input 
        chunkInfoModule_A.io.j_x              := i_w_next
        chunkInfoModule_A.io.x_elems_per_reg  := w_elems_per_reg
        chunkInfoModule_A.io.elemsPerChunk_in := elemsPerChunk_w
        chunkInfoModule_A.io.adr_X            := adr_W
        chunkInfoModule_A.io.RegsPerChunk_in  := RegsPerChunk_w

        //output
        elements_to_read := chunkInfoModule_A.io.elements_to_read 
        chunk_addres     := chunkInfoModule_A.io.chunk_address
      }

      when(dma.io.d_valid) { // response from DMA in D channel   
        val i_w_temp_next      = i_w_temp + elements_to_read_temp
        val dma_counter_d_next = dma_counter_d + elements_to_read_temp

        val data  = dma.io.readData  // UInt(64.W)
        val bytes = VecInit(Seq.tabulate(64 / params.WBitWidth)(i => data((i + 1) * params.WBitWidth - 1, i * params.WBitWidth).asSInt))
        
        for (i <- 0 until 64 / params.WBitWidth) {
          when(i.U < bytes_to_read ) {
            W_reg(f_idx)(reg_idx_start + i.U)(buff_index) := bytes(offset_in_chunk_2 + i.U)
          }
        }
        dma_counter_d := dma_counter_d_next
        dma_resp      := dma_counter_d < all_available_elems - elements_to_read_temp
        i_w_temp      := i_w_temp_next

        //input 
        chunkInfoModule_D.io.j_x_temp         := i_w_temp_next
        chunkInfoModule_D.io.x_elems_per_reg  := w_elems_per_reg
        chunkInfoModule_D.io.elemsPerChunk_in := elemsPerChunk_w
        chunkInfoModule_D.io.RegsPerChunk_in  := RegsPerChunk_w
        chunkInfoModule_D.io.dma_counter_d    := dma_counter_d_next

        //output 
        bytes_to_read         :=  chunkInfoModule_D.io.bytes_to_read 
        reg_idx_start         :=  chunkInfoModule_D.io.reg_idx_start
        offset_in_chunk_2     :=  chunkInfoModule_D.io.offset_in_chunk_1
        elements_to_read_temp := chunkInfoModule_D.io.elements_to_read_temp
        
      }
      
          
      when(!dma_resp && !dma_send) { //!dma_resp && !dma_send
        i_w                      := i_w_start
        j_w                      := j_w + 1.U
        f_idx                    := 0.U
        dma_counter_a            := 0.U
        dma_send                 := true.B
        dma_resp                 := true.B
        lock                     := false.B
        buff_elems(buff_index)   := dma_counter_d
        dma_counter_d            := 0.U
        buffers_mode(buff_index) := true.B

        ///next W elements 
        val remain_in_column_regs = (cin_reg - i_w_start  + w_elems_per_reg -1.U)/w_elems_per_reg
        val XS_W_temp             = Mux(remain_in_column_regs >= x_slice_weights_reg,x_slice_weights_reg,remain_in_column_regs)
        XS_W := XS_W_temp 
        ///next W elements 

        load_w_buff_idx := load_w_buff_idx + 1.U //Mux( load_w_buff_idx === (buffers - 1).U ,load_w_buff_idx + 1.U,0.U)
        w_count         := w_count + 1.U
 
        //before load W
        val temp_mul1 = (j_w + 1.U) * cin_reg 
        val temp_mul2  = XS_W_temp * w_elems_per_reg 

        mul1 := temp_mul1 
        mul2 := temp_mul2

        val bit_offset_in_byte = (((temp_mul1) + i_w_start) * weight_bits) & (params.WBitWidth.U - 1.U)
        val skipInFirstByte    = bit_offset_in_byte / weight_bits 
        dirty_elems_w(0.U)     := skipInFirstByte //fix this  //load_w_buff_idx + 1.U
        all_available_elems    := ( temp_mul2).min(cin_reg - i_w_start) 
        i_w_temp               := i_w_start
 
        chunkInfoModule_A.io.j_x              := i_w_start 
        chunkInfoModule_A.io.x_elems_per_reg  := w_elems_per_reg
        chunkInfoModule_A.io.elemsPerChunk_in := elemsPerChunk_w
        chunkInfoModule_A.io.adr_X            := adr_W
        chunkInfoModule_A.io.RegsPerChunk_in  := RegsPerChunk_w
        chunkInfoModule_A.io.mul1             := temp_mul1
        chunkInfoModule_A.io.mul2             := temp_mul2

        elements_to_read          := chunkInfoModule_A.io.elements_to_read
        chunk_addres              := chunkInfoModule_A.io.chunk_address


        //input 
        chunkInfoModule_D.io.j_x_temp         := i_w_start 
        chunkInfoModule_D.io.x_elems_per_reg  := w_elems_per_reg
        chunkInfoModule_D.io.elemsPerChunk_in := elemsPerChunk_w
        chunkInfoModule_D.io.RegsPerChunk_in  := RegsPerChunk_w
        chunkInfoModule_D.io.mul1             := temp_mul1
        chunkInfoModule_D.io.mul2             := temp_mul2

        //output 
        bytes_to_read         := chunkInfoModule_D.io.bytes_to_read
        reg_idx_start         := chunkInfoModule_D.io.reg_idx_start
        offset_in_chunk_2     := chunkInfoModule_D.io.offset_in_chunk_1
        elements_to_read_temp := chunkInfoModule_D.io.elements_to_read_temp

      } 
  } 


}

   

class WithDataReuseAccelerator extends Config((site, here, up) => {
  case BuildRoCC => Seq(
    (p: Parameters) => {
      implicit val implicitParams: Parameters = p
      implicit val valName: ValName = ValName("MatMul_Data_Reuse_example")

      // Pass fbus to DataReuseExample
      LazyModule(
        new DataReuseExample(
          opcodes = OpcodeSet.all,            // Opcode used for the accelerator
          params  = Data_Reuse_Config.Data_Reuse_Config  // Use the config from the LinearFilterConfig object
        ) {
  
        }
      )
    }
  )
})