package Data_Reuse

import chisel3._
import chisel3.util._

import chisel3._
import chisel3.util._

class ChunkSignExtender(val XBitWidth: Int) extends Module {
  val io = IO(new Bundle {
    val data       = Input(UInt(XBitWidth.W))      // π.χ. 32 ή 64 bits packed data (ή ό,τι πλάτος χρειάζεσαι)
    val input_bits = Input(UInt(6.W))              // π.χ. 2,4,8 (μέγιστο 32 bits)
    val mask       = Input(UInt(XBitWidth.W))     // μάσκα για το chunk (π.χ. (1 << input_bits)-1)
    val idx        = Input(UInt(8.W))              // index του chunk
    val out        = Output(SInt(XBitWidth.W))    // sign extended output
  })

  // Παίρνουμε το chunk με shift και μάσκα (mask προ-υπολογισμένη έξω)
  val chunk = (io.data >> (io.idx * io.input_bits)) & io.mask

  // Sign extend ανάλογα με input_bits  
  // val se2  = Cat(Fill(XBitWidth - 2, chunk(1)),  chunk(1,0)).asSInt
  val se4  = Cat(Fill(XBitWidth - 4, chunk(3)),  chunk(3,0)).asSInt
  val se8  = Cat(chunk(7), chunk(7,0)).asSInt   // 8-bit two’s-comp

  // io.out := Mux1H(Seq(
  //   // (io.input_bits === 2.U) -> se2,
  //   (io.input_bits === 4.U) -> se4,
  //   (io.input_bits === 8.U) -> se8
  // )) 

  io.out := Mux(io.input_bits === 4.U,se4,se8)
}

// package Data_Reuse

// import chisel3._
// import chisel3.util._

// class ChunkSignExtender(val XBitWidth: Int) extends Module {
//   val io = IO(new Bundle {
//     val data       = Input(UInt(XBitWidth.W))    // Packed input data
//     val input_bits = Input(UInt(3.W))            // Input chunk size: 2, 4, 8 bits
//     val idx        = Input(UInt(8.W))            // Chunk index
//     val out        = Output(SInt(XBitWidth.W))   // Sign-extended chunk
//   })

//   // Constants for supported bit widths
//   // val CHUNK2 = 2.U
//   val CHUNK4 = 4.U
//   val CHUNK8 = 8.U

//   // Precompute shift amount
//   val shiftAmt = io.idx << io.input_bits  // idx * input_bits

//   // Shift to align desired chunk to LSB
//   val shifted = io.data >> shiftAmt

//   // Extract and sign-extend
//   // val chunk2 = shifted(1, 0).asSInt
//   val chunk4 = shifted(3, 0).asSInt
//   val chunk8 = shifted(7, 0).asSInt

//   // Extend manually using sign bit (to avoid large Cat/Fills)
//   // val out2 = Cat(Fill(XBitWidth - 2, chunk2(1)), chunk2.asUInt).asSInt
//   val out4 = Cat(Fill(XBitWidth - 4, chunk4(3)), chunk4.asUInt).asSInt
//   val out8 = Cat(Fill(XBitWidth - 8, chunk8(7)), chunk8.asUInt).asSInt

//   // Select correct extension
//   io.out := MuxLookup(io.input_bits, 0.S, Seq(
//     // CHUNK2 -> out2,
//     CHUNK4 -> out4,
//     CHUNK8 -> out8
//   ))
// }


