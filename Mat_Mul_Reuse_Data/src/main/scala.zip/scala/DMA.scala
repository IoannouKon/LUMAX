// package Data_Reuse

// import chisel3._
// import chisel3.util._
// import freechips.rocketchip.subsystem.{BaseSubsystem, CacheBlockBytes}
// import org.chipsalliance.cde.config.{Parameters, Field, Config}
// import freechips.rocketchip.diplomacy.{LazyModule, LazyModuleImp, IdRange}
// import freechips.rocketchip.tilelink._
// import freechips.rocketchip.diplomacy.BufferParams
// import Data_Reuse.Data_Reuse_Config


// // case object DataReuseKey extends Field[DataReuseParams]

// class DmaModule(val params: DataReuseParams)(implicit p: Parameters) extends LazyModule {
//     val dmaIds = params.Dma_Ids

//   val node = TLClientNode(Seq(TLMasterPortParameters.v1(Seq(TLClientParameters(name = "DMA", requestFifo = true,sourceId = IdRange(0, dmaIds)))))) //dmaIds is how many request to memory can do the same time ,  differnt IDs 
//   lazy val module = new DmaModuleImp(this)
// }

//  class DmaModuleImp(outer: DmaModule) extends LazyModuleImp(outer) {
//   val io = IO(new Bundle {
//     //DMA interface 
//     val addr       = Input(UInt(64.W))    // Address to Read or Write  
//     val log_S      = Input(UInt(64.W))    // Size of address  
//     val mode       = Input(UInt(2.W))     // 0 -> Read from Memory, 1 -> Write to Memory
//     val valid      = Input(Bool())        // Valid input
//     val mask       = Input(UInt(64.W))    // mask to write in memory 64 bits Chunk 

//     // A Channel Signals  
//     val writeData  = Input(UInt(64.W)) // Data to be written (only used for write mode)
//     val a_fire     = Output(Bool())  
//     val a_cor      = Output(Bool()) 

//     //D Channel Signals 
//     val readData   = Output(UInt(64.W))   // Data read from memory (only valid in read mode)
//     val d_ready    = Input(Bool())
//     val d_valid    = Output(Bool()) 
//     val d_cor      = Output(Bool()) 
//     val d_den      = Output(Bool()) 

//     val tag        = Output(UInt(64.W))
//     val busy       = Output(Bool())
//     val empty      = Output(Bool())
//     val err        = Output(Bool())

//     //debug 
//     // val outstanding_vec = Output(UInt(ID.W))
//     val SourceOut   = Output(UInt(64.W)) 
    
//   }) 
//   val params = outer.params  // now comes from the constructor directly
//   val ID = params.Dma_Ids 

//   // Initialize TileLink interface
//   val (mem, edge) = outer.node.out(0)
//   val addrBits = edge.bundle.addressBits
//   val blockBytes = 8.U  

//   // A Channel Signals 
//    io.a_fire := mem.a.fire() 
//    io.a_cor  := mem.a.bits.corrupt

//    // D Channel Signals 
//    io.d_valid := mem.d.fire() //mem.d.valid
//    io.d_cor   := mem.d.bits.corrupt  
//    io.d_den   := mem.d.bits.denied  

//   val outstanding = RegInit(VecInit(Seq.fill(ID)(false.B))) // false -> ID not used 
//   val available = VecInit(outstanding.map(!_)).asUInt
//   val nextSource = PriorityEncoder(available)
//   val hasFree = available.orR
//   val counter_source = RegInit(0.U(log2Ceil(ID + 1).W))


//   // Σύνδεση Channel D απευθείας με το TLBuffer
//   io.readData := mem.d.bits.data
//   mem.d.ready := true.B  // Το TLBuffer διαχειρίζεται το backpressure (not use TLBuffer now)

//   io.busy   := outstanding.reduce(_ && _) 
//   io.empty  := outstanding.reduce(_ && !_)

//   // Initialize memory operation signals
//   mem.a.valid := io.valid && (io.mode === 1.U || io.mode === 0.U)   

//   val a_bits = WireDefault(mem.a.bits)
//   a_bits := DontCare
//   when (io.valid && hasFree) {
//     a_bits := Mux(io.mode === 0.U,
//       edge.Get(fromSource = nextSource, toAddress = io.addr, lgSize = io.log_S)._2,
//       edge.Put(fromSource = nextSource, toAddress = io.addr, lgSize = io.log_S, data = io.writeData, mask = io.mask)._2
//     )
//      io.SourceOut := nextSource //debug
//   }
//   mem.a.bits := a_bits
//   mem.a.valid := io.valid && hasFree


//    //when the request (read/write) is successfully send on the TileLink A channe
//   when (mem.a.fire()) { 
//       outstanding(nextSource) := true.B  
//   }

//   // Handle completion of memory operation (receive response)
//   when (mem.d.fire()) { 
//       outstanding(mem.d.bits.source) := false.B
//   }
  
//   io.tag := mem.d.bits.source
// }



package Data_Reuse

import chisel3._
import chisel3.util._
import freechips.rocketchip.subsystem.CacheBlockBytes
import org.chipsalliance.cde.config.Parameters
import freechips.rocketchip.diplomacy.{LazyModule, LazyModuleImp, IdRange}
import freechips.rocketchip.tilelink._
import Data_Reuse.Data_Reuse_Config

class DmaModule(val params: DataReuseParams)(implicit p: Parameters) extends LazyModule {
  val dmaIds = params.Dma_Ids
  val node = TLClientNode(Seq(TLMasterPortParameters.v1(Seq(
    TLClientParameters(name = "DMA", requestFifo = false, sourceId = IdRange(0, dmaIds))
  ))))
  lazy val module = new DmaModuleImp(this)
}

class DmaModuleImp(outer: DmaModule) extends LazyModuleImp(outer) {
  val io = IO(new Bundle {
    val addr       = Input(UInt(64.W))
    val log_S      = Input(UInt(64.W))
    val mode       = Input(UInt(2.W))
    val valid      = Input(Bool())
    val mask       = Input(UInt(64.W))
    val writeData  = Input(UInt(64.W))
    val a_fire     = Output(Bool())
    val a_cor      = Output(Bool())
    val readData   = Output(UInt(64.W))
    val d_ready    = Input(Bool())
    val d_valid    = Output(Bool())
    val d_cor      = Output(Bool())
    val d_den      = Output(Bool())
    val tag        = Output(UInt(64.W))
    val busy       = Output(Bool())
    val empty      = Output(Bool())
    val err        = Output(Bool())
    val SourceOut  = Output(UInt(64.W))
  })

  val params = outer.params
  val ID = params.Dma_Ids

  val (mem, edge) = outer.node.out(0)
  val outstanding = RegInit(VecInit(Seq.fill(ID)(false.B)))
  val available = VecInit(outstanding.map(!_)).asUInt
  val nextSource = PriorityEncoder(available)
  val hasFree = available.orR

  val a_bits = Wire(mem.a.bits.cloneType)
  a_bits := Mux(io.mode === 0.U,
    edge.Get(fromSource = nextSource, toAddress = io.addr, lgSize = io.log_S)._2,
    edge.Put(fromSource = nextSource, toAddress = io.addr, lgSize = io.log_S, data = io.writeData, mask = io.mask)._2
  )

  mem.a.bits := a_bits
  mem.a.valid := io.valid // && hasFree
  io.a_fire := mem.a.fire()
  io.a_cor := mem.a.bits.corrupt

  mem.d.ready := true.B
  io.readData := mem.d.bits.data
  io.d_valid := mem.d.valid //    mem.d.fire()
  io.d_cor := mem.d.bits.corrupt
  io.d_den := mem.d.bits.denied
  io.tag := mem.d.bits.source

  when(mem.a.fire()) {
    outstanding(nextSource) := true.B
  }

  when(mem.d.fire()) {
    outstanding(mem.d.bits.source) := false.B
  }

  io.SourceOut := nextSource
  io.busy := outstanding.reduce(_ && _)
  io.empty := outstanding.reduce(_ && !_)
  io.err := false.B // Optional error logic can go here
}
